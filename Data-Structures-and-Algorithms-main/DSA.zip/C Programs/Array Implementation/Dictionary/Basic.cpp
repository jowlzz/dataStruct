#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 60

typedef struct{
	char elem[50];
	int next;
}dInfo;

typedef dInfo dType[MAX];

typedef struct words{
	dType info;
	int last;
}*Dictionary;

typedef enum {TRUE, FALSE}boolean;

void initialize(Dictionary *A);
/*int getHash(char *data);
int allocSpace (Dictionary *A);
void insert(Dictionary *A, char *data);
void deleteWord(Dictionary *A, char *data);
boolean Member (Dictionary A, char *data);
void display (Dictionary A);*/

int main()
{
	Dictionary X;
	int action;
	char choice;
	char data[50];
	
	initialize(&X);
	/*do{
		printf("\n(1) Insert \n(2) Delete \n(3)Display");
		printf("\n Enter action : ");
		scanf("%d", &action);
		fflush(stdin);
		switch(action){
			case 1 : printf("\n Enter word you want to insert: ");
					 scanf("%s", &data);
					 fflush(stdin);
					 insert(&X, data);
					 break;
			case 2 : printf("\n Enter word you want to delete: ");
					 scanf("%s", &data);
					 fflush(stdin);
					 deleteWord(&X, data);
					 break;
			default : display(X);
		}
		printf("\n Do you want to continue (Y or N)? ");
		scanf("%c", &choice);
		fflush(stdin);
	}while (choice=='Y'||choice=='y');
	
	display(X);*/
	getch();
	return 0;
}

void initialize(Dictionary *A)
{
	int i;
	
	*A=(Dictionary)malloc(sizeof(struct words));
	for(i=0;i<26;i++){
		strcpy((*A)->info[i].elem,"EMPTY");
		(A)->info[i].next=-1;
	}
	(*A)->last=25;
	
	for(i=(*A)->last+1;i<MAX-1;i++){
		(*A)->info[i].next=i+1;
	}
	(*A)->info[MAX-1].next=-1;
}

/*int getHash(char data)
{
	int p, retVal;
	
	if(data>64&&data<91){
		retVal=65;
	} else {
		retVal=97;
	}
	return (data-retVal);
}
int allocSpace (Dictionary *A)
{
	int ndx;
		for(ndx=26;ndx<=(*A).last && strcmp((*A).info[ndx].elem,"DELETED")!=0;ndx=ndx+1){}
		if(ndx>(*A).last && ndx!=MAX){
			(*A).last=ndx;
		}
	return ndx;
}
void insert(Dictionary *A, char *data)
{
	int hashVal, ndx;
	
	if(Member(*A, data)==FALSE){
		hashVal=getHash(data[0]);
		if(strcmp((*A).info[hashVal].elem,"EMPTY")==0 || strcmp((*A).info[hashVal].elem,"DELETED")==0){
				strcpy((*A).info[hashVal].elem, data); 
		} else {
			ndx=allocSpace (A);
			if(ndx!=MAX){
				(*A).info[ndx].next=(*A).info[hashVal].next;
				(*A).info[hashVal].next=ndx;
				strcpy((*A).info[ndx].elem, data);
			}
		}
	}
}
void deleteWord(Dictionary *A, char *data)
{
	int ndx, hashVal, temp;
	
	hashVal=getHash(data[0]);
	for(ndx=hashVal;ndx!=-1 && strcmp((*A).info[ndx].elem, data)!=0;temp=ndx, ndx=(*A).info[ndx].next){}
	if(ndx!=-1){
		if(ndx!=hashVal){
			(*A).info[temp].next=(*A).info[ndx].next;
			(*A).info[ndx].next=(*A).last+1;
		}
		strcpy((*A).info[ndx].elem,"DELETED");
	}
}
boolean Member (Dictionary A, char *data)
{
	int hashVal, trav;
	
	hashVal=getHash(data[0]);
	
	for(trav=hashVal; trav!=-1 && strcmp(A.info[trav].elem, data)!=0; trav=A.info[trav].next){}
	
	return (trav==-1?FALSE:TRUE);
}

void display (Dictionary A)
{
	char letter;
	int hashVal;
	
	for(letter='A';letter<91;letter++){
		hashVal=getHash(letter);
		printf("\n Words for letter %c", letter);
		while(hashVal!=-1){
			if(strcmp(A.info[hashVal].elem, "DELETED")!=0){
				printf("\n %s",A.info[hashVal].elem);
			}
			hashVal=A.info[hashVal].next;
		}
	}
}*/
