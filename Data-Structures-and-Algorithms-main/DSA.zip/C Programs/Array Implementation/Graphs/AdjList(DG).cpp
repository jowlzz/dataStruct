#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 7

typedef struct node{
	int elem;
	struct node *next;
}*listType;

typedef struct cell{
	listType front;
	listType rear;
}*Queue;

typedef listType GRAPH[SIZE];
typedef unsigned char SET;

GRAPH* initGraph();
void createGraph(GRAPH *A, SET *vert);
void dfs (GRAPH A, int v, int *mark);
void initQueue (Queue *Q);
void enqueue (Queue *Q, int elem);
void dequeue (Queue *Q);
int frontQueue (Queue Q);
void bfs(GRAPH A, int v, int *mark);
void printGraph(GRAPH A);

int main ()
{
	GRAPH *DG;
	int i;
	SET val[]={6, 12, 1, 5, 96, 2, 40};
	int mark[SIZE];
	
	DG=initGraph();
	createGraph(DG, val);
	printGraph(*DG);
	
	printf("\n Depth First Search: ");
	memset(mark, -1, sizeof(int)*SIZE);
	printf("\n What vertex do you want to start with: ");
	scanf("%d", &i);
	fflush(stdin);
	dfs(*DG, i, mark);
	
	memset(mark, -1, sizeof(int)*SIZE);
	printf("\n Breadth First Search: ");
	printf("\n What vertex do you want to start with: ");
	scanf("%d", &i);
	fflush(stdin);
	bfs(*DG, i, mark);
	
	getch();
	return 0;
}

GRAPH* initGraph()
{
	GRAPH *A;
	int i;
	
	A=(GRAPH *)malloc(sizeof(GRAPH));
	for(i=0;i<SIZE;i++){
		(*A)[i]=NULL;
	}
	
	return A;
}

void createGraph(GRAPH *A, SET *vert)
{
	SET mask;
	int i, ctr;
	listType temp, *trav;
	
	mask=0;
	for(i=0;i<SIZE;i++){
		trav=&(*A)[i];
		mask=1<<(sizeof(char)*SIZE-1);
		for(ctr=SIZE-1;ctr>-1;ctr--){
			if(mask&vert[i]){
				temp=(listType)malloc(sizeof(struct node));
					if(temp!=NULL){
						temp->elem=ctr;
						temp->next=*trav;
						*trav=temp;
					}
			}
			mask>>=1;
		}
	}
	
}

void dfs (GRAPH A, int v, int *mark)
{
	int adj, i;
	//SET mask;
	listType trav;
	
	//mask=0;
	//mask=1<<(sizeof(char)*v);
	//mark=mark|mask;
	mark[v]=0;
	printf("\n %d",v);
	
	for(trav=A[v];trav!=NULL; trav=trav->next){
		if(mark[trav->elem]==-1){
			dfs(A, trav->elem, mark);
		}
		/*mark=mark|mask;
		mask=1<<(sizeof(char)*(trav->elem));
		if(!(mark&mask)){
			dfs(A, trav->elem, mark);
		}*/
	}
	
	for(adj=0;adj<SIZE && mark[adj]==0;adj++){}
	
	if(adj<SIZE){
		dfs(A, adj, mark);
	}
	/*for(adj=mask=0;adj<SIZE && (mask&mark);mask=1<<(sizeof(char)*adj), adj++){}
	if(adj<SIZE){
		dfs(A, adj, mark);
	}*/
	
}

void initQueue (Queue *Q)
{
	*Q=(Queue)malloc(sizeof(struct cell));
	(*Q)->front=(*Q)->rear=NULL;
}

void enqueue (Queue *Q, int elem)
{
	listType temp;
	
	temp=(listType)malloc(sizeof(struct node));
	if(temp!=NULL){
		temp->elem=elem;
		temp->next=NULL;
		if ((*Q)->front==NULL){
			(*Q)->front=temp;
		} else {
			(*Q)->rear->next=temp;
		}
		(*Q)->rear=temp;
	}
}

void dequeue (Queue *Q)
{
	listType temp;
	
	if((*Q)->front!=NULL){
		temp=(*Q)->front;
		(*Q)->front=temp->next;
		free(temp);
	}
	
	if((*Q)->front==NULL){
		(*Q)->rear=NULL;
	}
}

int frontQueue (Queue Q)
{
	return (Q->front->elem);
}

void bfs(GRAPH A, int v, int *mark)
{
	Queue hold;
	int x, y;
	listType trav;
	
	initQueue(&hold);
	mark[v]=0;
	printf("\n %d", v);
	enqueue(&hold, v);
	
	while(hold->front!=NULL){
		x=frontQueue(hold);
		dequeue(&hold);
		for(trav=A[x];trav!=NULL;trav=trav->next){
			if(mark[trav->elem]==-1){
				mark[trav->elem]=0;
				printf("\n %d", trav->elem);
				enqueue(&hold, trav->elem);
			}
		}
	}
	
	for(x=0;x<SIZE && mark[x]==0;x++){}
	if(x<SIZE){
		bfs(A, x, mark);
	}
	
}

void printGraph(GRAPH A)
{
	int i;
	listType trav;
	
	for(i=0;i<SIZE;i++){
		printf("\n Vertices adjacent to %d: ", i);
		for(trav=A[i];trav!=NULL;trav=trav->next){
			printf("\n %-8d", trav->elem);
		}
		printf("\n");
	}
}
