#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define INFINITE 1000
#define VISITED -2
#define UNVISITED -3
#define SIZE 5

typedef unsigned char SET;

typedef int diGraph[SIZE][SIZE];

typedef struct{
	int head, tail;
	int queue[SIZE+1];
}qType;

void initQueue (qType *Q);
diGraph* createMat (SET *S);
diGraph* giveWeight (diGraph A);
int * Dijkstra (int vertex, diGraph A);
int min (int num1, int num2);
diGraph* Floyd (diGraph A);
diGraph* Warshall (diGraph A);
int findCent (diGraph A);
void dfs (int v, diGraph A, int *mark);
void bfs(int v, diGraph A, qType *Q);
void printAdj (diGraph C);
void printMatrix (diGraph A);

int main ()
{
	SET A []={26, 4, 17, 20, 0};
	int v, i;
	diGraph *D, *L, *allSP, *TC;
	int *minPath, mark[SIZE];
	qType Q;
	unsigned char mask;
	
	D=createMat (A);
	printMatrix(*D);
	printf("\n Adjacent Paths of Graphs: ");
	printAdj(*D);
	
	printf("\n\n Transitive closure of graph: ");
	TC=Warshall(*D);
	printMatrix(*TC);
	
	printf("\n Weighted Graph: ");
	L=giveWeight (*D);
	printMatrix(*L);
	
	printf("\n \n Enter the vertex you want to find the shortest paths of: ");
	scanf("%d", &v);
	fflush(stdin);
	
	minPath=Dijkstra(v, *L);
	printf("\n The minimum paths of vertex %d: ", v);
	for (i=0;i<SIZE;i++){
		printf("\n From Vertex %d to %d, the shortest path is %d", v, i, minPath[i]);
	}
	
	allSP=Floyd(*L);
	printf("\n Weighted with APSP: ");
	printMatrix(*allSP);
	
	printf("\n The center of the graph is %d", findCent(*allSP));
	
	memset(mark, UNVISITED, SIZE);
	for(i=0;i<SIZE;i++){
		mark[i]=UNVISITED;
	}
	printf("\n Depth First Search: ");
	dfs(1, *D, mark);
	printf("\n Breadth First Search: ");
	initQueue (&Q);
	bfs(0, *D, &Q);
	
	getch();
	return 0;
}

diGraph* createMat (SET *S)
{
	diGraph *M;
	unsigned char mask;
	int i, ctr;
	
	M=(diGraph *)malloc(sizeof(diGraph));
	if(M!=NULL){
		for(i=0;i<SIZE;i++){
			mask=1<<(sizeof(char)*(SIZE-1));
			for(ctr=SIZE-1;ctr>-1;ctr--){
				if (S[i] & mask){
					(*M)[i][ctr]=1;
				} else {
					(*M)[i][ctr]=0;
				}
				mask>>=1;
			}	
		}
	}
	return M;	
}

diGraph* giveWeight (diGraph A)
{
	int ran [] = {10, 30, 100, 50, 20, 10, 20, 60};
	diGraph *W;
	int j, k, ctr;
	
	W=(diGraph *)malloc(sizeof(diGraph));
	if(*W!=NULL){
		ctr=0;
		for(k=0;k<SIZE;k++){
			for(j=0;j<SIZE;j++){
				if(A[k][j]==1){
					(*W)[k][j]=ran[ctr];
					ctr++;
				} else {
					(*W)[k][j]=INFINITE;
				}
			}
		}	
	}
	return W;
}

int * Dijkstra (int vertex, diGraph A)
{
	int *arr, j, mini, ctr, k, S[SIZE];
	unsigned char mask;
	//SET S;
	
	/*S=0;*/
	arr=(int *)malloc(sizeof(int)*SIZE);
	/*mask=1<<(sizeof(char)*vertex);
	S=S|mask;*/
	
	S[vertex]=1;
	
	memcpy(arr, A[vertex], sizeof(int)*SIZE);
	
	for(j=1, mask=0;j<SIZE;j++){
		for(k=1, mini=0;k<SIZE;k++){
			/*mask=1<<(sizeof(char)*k);
			if((!(S&mask)) && arr[mini]>arr[k]){
				mini=k;
			}*/
			if(S[k]!=1 && arr[k]<arr[mini]){
				mini=k;
			}
		}
		
		//printf("\n %d", mini);
		S[mini]=1;	
		/*mask=0;
		mask=1<<(sizeof(char)*mini);
		S=S|mask;
		
		for(ctr=mask=0;ctr<SIZE;ctr++){
			mask<<=1;
			if(!(S&mask)){
				arr[ctr]=min(arr[ctr], arr[mini]+A[mini][ctr]);
			}
		}*/
		
		for(ctr=0;ctr<SIZE;ctr++){
			if(S[ctr]!=1){
				arr[ctr]=min(arr[ctr], arr[mini] + A[mini][ctr]);
			}
		}
	}
	
	return arr;
}

int min (int num1, int num2)
{
	return (num1>num2?num2:num1);
}

diGraph *Floyd (diGraph A)
{
	diGraph *W;
	int j, k, m;
	
	W=(diGraph *)malloc(sizeof(diGraph));
	if(*W!=NULL){
		for(k=0;k<SIZE;k++){
			for(j=0;j<SIZE;j++){
				(*W)[k][j]=A[k][j];
			}
		}
		for(k=0;k<SIZE;k++){
			(*W)[k][k]=0;
		}
		
		for(m=0;m<SIZE;m++){
			for(k=0;k<SIZE;k++){
				for(j=0;j<SIZE;j++){
					if((*W)[k][m]+(*W)[m][j] < (*W)[k][j]){
						(*W)[k][j]=(*W)[k][m]+(*W)[m][j];
					}
				}
			}
		}
	}
	return W;
}

diGraph *Warshall (diGraph A)
{
	diGraph *T;
	int j, k, m;
	
	T=(diGraph *)malloc(sizeof(diGraph));
	if(*T!=NULL){
		for(k=0;k<SIZE;k++){
			for(j=0;j<SIZE;j++){
				(*T)[k][j]=A[k][j];
			}
		}
	
		for(m=0;m<SIZE;m++){
			for(k=0;k<SIZE;k++){
				for(j=0;j<SIZE;j++){
					if((*T)[k][j]==0){
						(*T)[k][j]=((*T)[k][m]&&(*T)[m][j]);	
					}
				}
			}
		}
	}
	
	return T;
}

int findCent (diGraph A)
{
	int j, k, cnt, cent;
	int arr[SIZE];
	
	for(k=0, cnt=0;k<SIZE;k++, cnt++){
		arr[cnt]=A[0][k];
		for(j=1;j<SIZE;j++){
			if(arr[cnt]<A[j][k] && A[j][k]!=INFINITE){
				arr[cnt]=A[j][k];
			} 
		}
	}
	
	for(j=1;j<SIZE;j++){
		cent=0;
		if(arr[cent]>arr[j]){
			cent=j;
		}
	}
	
	return cent;
}

void dfs (int v, diGraph A, int *mark)
{
	int w;
	
	mark[v]=VISITED;
	printf("\n %d", v);
	
	for(w=0;w<SIZE;w++){
		if (A[v][w]==1 && mark[w]==UNVISITED){
			dfs(w, A, mark);
		}
	}
	
	for(w=0;w<SIZE && mark[w]==VISITED;w++){}
	if(mark[w]==UNVISITED){
		dfs(w, A, mark);
	}
}

void initQueue (qType *Q)
{
	Q->head=0;
	Q->tail=SIZE;
}


void bfs(int v, diGraph A, qType *Q)
{
	int mark[SIZE], x, y, trav;
	
	
	for(x=0;x<SIZE;x++){
		mark[x]=UNVISITED;
	}
	
	mark[v]=VISITED;
	printf("\n %d", v);
	trav=(Q->tail+1)%SIZE;
	Q->queue[trav]=v;
	Q->tail=trav;
	
	while(Q->head!=(Q->tail+1)%SIZE){
		x=Q->queue[Q->head];
		Q->head=(Q->head+1)%SIZE;
		for(y=0;y<SIZE;y++){
			if(A[x][y]==1 && mark[y]==UNVISITED){
				mark[y]=VISITED;
				printf("\n %d", y);
				trav=(Q->tail+1)%SIZE;
				Q->queue[trav]=y;
				Q->tail=trav;			
			}
		}
	}
}
void printAdj (diGraph C)
{
	int k, j;
	
	for(k=0;k<SIZE;k++){
		printf("\n The adjacent vertices for vertex %d: ", k);
		for(j=0;j<SIZE;j++){
			if(C[k][j]==1){
				printf("%8d", j);
			}
		}
	}
}

void printMatrix (diGraph A)
{
	int k, j;
	
	for(k=0;k<SIZE;k++){
		printf("\n");
		for(j=0;j<SIZE;j++){
			printf("%-8d", A[k][j]);
		}
	}
}
