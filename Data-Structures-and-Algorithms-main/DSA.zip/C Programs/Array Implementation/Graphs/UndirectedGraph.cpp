#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define INFINITE 999
#define SIZE 6

typedef struct node{
	int val;
	struct node *next;
}*lType;

typedef int GRAPH[SIZE][SIZE];
typedef unsigned char SET;

typedef struct{
	GRAPH span;
	int mincost;
}MST;


GRAPH* createGraph(SET *S);
GRAPH* giveWeight(GRAPH A);
GRAPH* warshall (GRAPH A);
MST primAlg (GRAPH A);
MST prim (GRAPH A);
MST kruskal (GRAPH A);
void bfs(GRAPH A, int vertex, int *mark);
void dfs(GRAPH A, int vertex, int *mark);
void printMatrix (GRAPH A);
void printAdj (GRAPH A);
void printMST(MST M);

int main ()
{
	GRAPH *TC;
	MST hold;
	SET A []={38, 37, 11, 21, 41, 19};
	GRAPH B={{0,1,1,1,1,1},
				{1,0,1,0,0,1},
				{1,1,0,1,0,0},
				{1,0,1,0,1,0},
				{1,0,0,1,0,1},
				{1,1,0,0,1,0}};
	GRAPH lab={{999,1,5,4,6,5},
				{1,999,5,999,999,6},
				{1,1,999,1,999,999},
				{4,999,2,999,1,999},
				{6,999,999,1,999,3},
				{5,6,999,999,3,999}};			
		
	//B=createGraph(A);
	printMatrix(B);
	printf("\n Adjacent Paths of Graph: ");
	printAdj(B);
	
	printf("\n Transitive Closure of Matrix: ");
	printMatrix(*(warshall(B)));
	
	//lab=giveWeight(B);
	printf("\n Weighted Graph: ");
	printMatrix(lab);
	
	printf("\n MST using Prim's Algorithm: ");
	hold=prim(lab);
	//printMST(primAlg(*lab));
	
	//printf("\n The Minimum Cost using prim's algorithm is %d", primAlg(lab));
	
	/*printf("\n MST using Kruskal's Algorithm: ");
	printMST(kruskal(*lab));*/
	
	getch();
	return 0;
}

GRAPH* createGraph(SET *S)
{
	SET mask;
	int j, ctr, i;
	GRAPH temp={{0,1,1,1,1,1},
				{1,0,1,0,0,1},
				{0,1,0,1,0,0},
				{0,0,1,0,1,0},
				{1,0,0,1,0,1},
				{1,1,0,0,1,0}};
	GRAPH *M;
	
	//mask=0;
	/*if(M!=NULL){
		for(i=0;i<SIZE;i++){
			mask=1<<(sizeof(char)*SIZE-1);
			for(ctr=SIZE-1;ctr>-1;ctr--){
				if(S[ctr] & mask){
					(*M)[i][ctr]=1;
				} else {
					(*M)[i][ctr]=0;
				}
				mask>>=1;
			}
		}
	}*/
	M=&temp;
	
	return M;
}

GRAPH* giveWeight(GRAPH D)
{
	int ran []= {1, 5, 4, 6, 5, 5, 6, 2, 1, 3};
	int j, k, ctr;
	GRAPH *A;
	
	A=(GRAPH *)malloc(sizeof(GRAPH));
	ctr=0;
	for(k=0;k<SIZE;k++){
		for(j=0;j<SIZE;j++){
			if(D[k][j]==1){
				(*A)[k][j]=ran[ctr];
				ctr++;
			} else if (D[k][j]==0){
				(*A)[k][j]=INFINITE;
			}
		}
	}
	return A;
}

GRAPH* warshall (GRAPH A)
{
	int i, j, k;
	GRAPH *T;
	
	T=(GRAPH *)malloc(sizeof(GRAPH));
	if(T!=NULL){
		for(i=0;i<SIZE;i++){
			for(k=0;k<SIZE;k++){
				(*T)[i][k]=A[i][k];
			}
		}
		
		for(k=0;k<SIZE;k++){
			for(j=0;j<SIZE;j++){
				for(i=0;i<SIZE;i++){
					if((*T)[j][i]==0){
						(*T)[j][i]=((*T)[j][k]&&(*T)[k][i]);
						(*T)[i][j]=(*T)[j][i];
					}
				}
			}
		}
	}
	return T;
}

/*MST primAlg (GRAPH A)
{
	MST T;
	int mini, p, k, j;


	memset(T.span, -1, sizeof(int)*SIZE);
	T.mincost=0;
	p=0;
	mini=999;
	
	
	
	return T;
}*/

MST prim(GRAPH A) 
{
   int i, j, startVertex, endVertex;
   int k, nr[10], temp, minimumCost = 0, tree[10][3];
   MST T;
 
   /* For first smallest edge */
   temp = A[0][0];
   for (i = 0; i < SIZE; i++) {
      for (j = 0; j < SIZE; j++) {
         if (temp > A[i][j]) {
            temp = A[i][j];
            startVertex = i;
            endVertex = j;
         }
      }
   }
   /* Now we have fist smallest edge in graph */
   T.span[0][0] = startVertex;
   T.span[0][1] = endVertex;
   T.span[0][2] = temp;
   T.mincost = temp;
 
   /* Now we have to find min dis of each vertex from either
    startVertex or endVertex by initialising nr[] array
    */
 
   for (i = 0; i < SIZE; i++) {
      if (A[i][startVertex] < A[i][endVertex])
         nr[i] = startVertex;
      else
         nr[i] = endVertex;
   }
 
   /* To indicate visited vertex initialise nr[] for them to 100 */
   nr[startVertex] = 100;
   nr[endVertex] = 100;
 
   /* Now find out remaining n-2 edges */
   temp = 99;
   for (i = 1; i < SIZE - 1; i++) {
      for (j = 0; j < SIZE; j++) {
         if (nr[j] != 100 && A[j][nr[j]] < temp) {
            temp = A[j][nr[j]];
            k = j;
         }
      }
      /* Now i have got next vertex */
      T.span[i][0] = k;
      T.span[i][1] = nr[k];
      T.span[i][2] = A[k][nr[k]];
      T.mincost = T.mincost + A[k][nr[k]];
      nr[k] = 100;
 
      /* Now find if k is nearest to any vertex
       than its previous near value */
 
      for (j = 0; j < SIZE; j++) {
         if (nr[j] != 100 && A[j][nr[j]] > A[j][k])
            nr[j] = k;
      }
      temp = 99;
   }
   
   printf("\n Min Cost: %d", T.mincost);
   return T;
}
//MST kruskal (GRAPH A);
//void bfs(GRAPH A, int vertex, int *mark);
//void dfs(GRAPH A, int vertex, int *mark);
void printMatrix (GRAPH A)
{
	int k, j;
	
	for(k=0;k<SIZE;k++){
		printf("\n");
		for(j=0;j<SIZE;j++){
			printf("%-8d", A[k][j]);
		}
	}
}
void printAdj (GRAPH A)
{
	int k, j;
	
	for(k=0;k<SIZE;k++){
		printf("\n The adjacent vertices for vertex %d: ", k);
		for(j=0;j<SIZE;j++){
			if(A[k][j]==1){
				printf("%8d", j);
			}
		}
	}
}
//void printMST(MST M);
