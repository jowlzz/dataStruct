#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define MAX 20

/*typedef struct{
	char LN[20];
	char FN[20];
	char MI;
}nameType;

typedef struct{
	nameType name;
	int pNum;
	char ID[11];
	char course[10];
	int year;
}studType;

typedef studType studRec[10];*/

typedef struct{
	int pNum[MAX];
	int last;
}minHeap;
typedef enum{TRUE, FALSE}boolean;

void initialize(minHeap **A);
boolean isHeap(minHeap A);
void insert(minHeap *A, int pNum);
int deleteMin(minHeap *A);
void heapSort(minHeap *A);
void heapify(minHeap *A);
void display(minHeap A);

int main ()
{
	minHeap *H;
	int num, trav;
	char option;
	
	initialize(&H);
	for(trav=0;trav<8 && (*H).last<MAX;trav++){
		printf("\n Enter priority number: ");
		scanf("%d", &num);
		fflush(stdin);
		(*H).pNum[trav]=num;
		(*H).last++;
	}
	
	printf("\n Before heapify: ");
	display(*H);
	heapify(H);
	printf("\n After heapify: ");
	display(*H);
	/*printf("\n After heapSort: ");
	heapSort(H);
	display(*H);
	heapify(H);
	
	for(trav=0, option='Y';trav<=(*H).last && (option=='Y'||option=='y');trav++){
		printf("\n Priority number %d has now been served", deleteMin(H));
		display(*H);
		printf("\n Do you still want to serve (Y or N)? ");
		scanf("%c", &option);
		fflush(stdin);
	}
	
	display(*H);*/
	insert (H, 10);
	insert (H, 7);
	display(*H);
	getch();
	return 0;
}

void initialize(minHeap **A)
{
	(*A)=(minHeap *)malloc(sizeof(minHeap));
	(**A).last=-1;
}

void insert(minHeap *A, int pNum)
{
	int ndx, parent, temp;
	
	ndx=(*A).last+1;
	if(ndx<MAX){
		for (parent=(ndx-1)/2;parent!=0 && pNum<(*A).pNum[parent];parent=(parent-1)/2){
			(*A).pNum[ndx]=(*A).pNum[parent];
			ndx=parent;
		}
		(*A).pNum[ndx]=pNum;
		(*A).last++;
	}		
}

int deleteMin(minHeap *A)
{
	int ndx, flag;
	int data, child, temp;
	
	ndx=0;
	data=(*A).pNum[0];
	(*A).pNum[ndx]=(*A).pNum[(*A).last];
	(*A).last--;
	child=(ndx*2)+1;
	flag=0;
	while (child<=(*A).last && flag==0){
		if(child+1<=(*A).last && (*A).pNum[child]>(*A).pNum[child+1]){
			child++;
		}
		if((*A).pNum[ndx]>(*A).pNum[child]){
			temp=(*A).pNum[ndx];
			(*A).pNum[ndx]=(*A).pNum[child];
			(*A).pNum[child]=temp;
			ndx=child;
			child=(child*2)+1;
		} else {
			flag=1;
		}
	}
	
	return data;
}

void heapSort(minHeap *A)
{
	int curr, temp, p;
	
	temp=(*A).last;
	
	for(p=(*A).last;p>-1;p--){
		(*A).pNum[p]=deleteMin(A);
	}
	(*A).last=temp;
}

void heapify(minHeap *A)
{
	int parent, child, temp, trav;

	for(trav=(*A).last-1/2;trav>-1;trav--){
		parent=trav;
		child=2*trav+1;
		while (child<=(*A).last && (*A).pNum[child]<(*A).pNum[parent] ||child+1<=(*A).last && (*A).pNum[child]>(*A).pNum[child+1]){
			if(child+1<=(*A).last && (*A).pNum[child]>(*A).pNum[child+1]){
				child++;
			}
			temp=(*A).pNum[parent];
			(*A).pNum[parent]=(*A).pNum[child];
			(*A).pNum[child]=temp;
			
			parent=child;
			child=2*child+1;
		}
	}
}

void display(minHeap A)
{
	int trav;
	printf("\n");
	for(trav=0;trav<=A.last;trav++){
		printf("\n %d", A.pNum[trav]);
	}
}

