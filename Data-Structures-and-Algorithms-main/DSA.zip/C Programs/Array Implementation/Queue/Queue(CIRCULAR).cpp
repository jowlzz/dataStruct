#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define SIZE 10

typedef struct cell{
	int head;
	int tail;
	int *array/*[SIZE]*/;
}Queue;

typedef enum{
	TRUE,FALSE
}boolean;

void initQueue(Queue *);
boolean isFull(Queue);
boolean isEmpty(Queue);
void enqueue(Queue * , int elem);
void dequeue(Queue *);
void display(Queue);

int main()
{
	Queue A;
	int choice, newElem;
	char option;
	
	initQueue(&A);
	    do{
		    printf("\n(1)Enqueue\n(2)Dequeue\nChoose an option (1 or 2): ");
		    scanf("%d", &choice);
		    fflush(stdin);
			switch(choice){
			case 1: printf("\n Enter the element you want to add? ");
					scanf("%d", &newElem);
					fflush(stdin);
					enqueue(&A, newElem);
					break;
			case 2: dequeue(&A);
					break;
			default:printf("\n The option you chose does not exist");
			}
			printf("\n Do you want to continue (Y or N)?");
			scanf("%c", &option);
			fflush(stdin);
		}while (option=='Y'||option=='y');
	    display(A);
	getch();
	return 0;
}

void initQueue(Queue *Q)
{
	Q->array=(int *)malloc(sizeof(int)*SIZE);
	Q->head=0;
	Q->tail=SIZE-1;
}

boolean isFull(Queue Q)
{
	return(Q.head==(Q.tail+2)%SIZE?TRUE:FALSE);
}

boolean isEmpty(Queue Q)
{
	return(Q.head==(Q.tail+1)%SIZE?TRUE:FALSE);
}

void enqueue(Queue *Q, int elem)
{
	int next;
	if (isFull(*Q)==TRUE){
		printf("\n Queue overflow");
	} else {
		next=(Q->tail+1)%SIZE;
		Q->array[next]=elem;
		Q->tail=next;
	}
}
void dequeue(Queue *Q)
{
	if(isEmpty(*Q)==TRUE){
		printf("\n Queue underflow");
	} else {
		Q->head=(Q->head+1)%SIZE;
	}
}
void display(Queue Q)
{
	for(;Q.head!=(Q.tail+1)%SIZE;Q.head=(Q.head+1)%SIZE){
		printf("\n Data: %d", Q.array[Q.head]);
	}
}

