#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 5

typedef struct{
	int front;
	int rear;
	char *arr;
}Queue;

void initQueue(Queue *);
void enqueue(Queue *, char/*, int **/);
void dequeue(Queue */*, int **/);
void display(Queue);

int main ()
{
	Queue A;
	char choice, data, retVal;
	int option;
	int avSpace;
	
	initQueue(&A);
	avSpace=0;
	do{
		printf("\n(1)Enqueue \n(2)Dequeue \n Enter your choice: ");
		scanf("%d", &option);
		fflush(stdin);
		switch(option){
			case 1: printf("\n Enter the data you want to enqueue: ");
					scanf("%c", &data);
					fflush(stdin);
					enqueue(&A, data /*&avSpace*/);
					break;
			case 2: /*retVal=**/dequeue(&A /*&avSpace*/);
					/*printf("\n The element dequeued is: %c", retVal);*/
					break;
			default: printf("\n The option you entered is invalid");
		}
		printf("\n Do you want to continue(Y or N)?");
		scanf("%c", &choice);
		fflush(stdin);
	} while(choice=='Y'||choice=='y');
	
	display(A);
	getch();
	return 0;
}

void initQueue(Queue *Q)
{
	Q->arr=(char *)malloc(sizeof(char)*SIZE);
	(Q)->front=-1;
	(Q)->rear=-1;
}

/*void enqueue(Queue *Q, char data, int *space)
{
	if(Q->rear==SIZE-1 && (*space)>0){
		memcpy(Q->arr, Q->arr+(*space), sizeof(char)*(SIZE-Q->front));
		Q->front=0;
		Q->rear=(SIZE-1)-(*space);
		*space=0;
	}
	if((Q->rear)<SIZE){
		Q->rear++;
		Q->arr[Q->rear]=data;
		if(Q->front==-1){
			Q->front=Q->rear;
		}
	}
}*/

void enqueue(Queue *Q, char data)
{
	if(Q->rear - Q->front < SIZE -1){
  		if(Q->rear == SIZE - 1){
			memcpy(Q->arr, Q->arr + Q->front, sizeof(char)*(SIZE - Q->front));
			Q->rear = Q->rear-Q->front;
  		}
  		Q->front=0;
		Q->arr[++Q->rear] = data;
	} else {
		printf("Queue is full!");
	}
}

/*char dequeue(Queue *Q, int *space)
{
	char retVal;
	if(Q->front!=-1){
		retVal=Q->arr[Q->front];
		Q->front++;
		(*space)++;
	}
	return retVal;	
}*/

void dequeue(Queue *Q)
{
	if(Q->front != -1 && Q->front<SIZE){
		if(Q->rear == Q->front){
			Q->rear++;
		}
		    Q->front++;
  	} else {
  		Q->front=-1;
  		Q->rear=-1;
		printf("Queue is empty!");
	}
}
void display(Queue Q)
{
	int trav;
	printf("\n The elements in the queue will be displayed from front to rear.");
	printf("\n The value of the front pointer is %d", Q.front);
	printf("\n The value of the rear pointer is %d", Q.rear);
	for(trav=Q.front;trav<=Q.rear;trav++){
		printf("\n Data: %c", Q.arr[trav]);
	}	
}
