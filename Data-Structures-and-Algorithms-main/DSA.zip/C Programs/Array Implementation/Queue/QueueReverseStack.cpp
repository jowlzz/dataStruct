#include<stdio.h>
#include<conio.h>
#include<stdlib.h>


typedef struct{
	char *array;
	int front;
	int rear;
}Queue, *queuePtr;

typedef struct{
	char *arr;
	int top;
}Stack, *stackPtr;


int initQueue(quePtr *);
int initStack(stackPtr *);
void enqueue(queuePtr, char);
void push(stackPtr, char);
char dequeue(queuePtr );
char pop(StackPtr );
void reverse(quePtr );
void display(quePtr );

int main()
{
	queuePtr A;
	char data, choice;
	
	initQueue(&A);
	do{
		printf("\n Enter the element you want to enqueue: ");
		scanf("%c", &data);
		enqueue(A, data);
		printf("\n Do you want to continue (Y or N)?")
		scanf("%c", &choice);
	} while(choice=='Y'||choice=='y');
	
	printf("\n The data inside the queue after enqueue");
	display(queuePtr);
	reverse(A);
	printf("\n The data after reversing using a stack ");
	display(queuePtr);
	
	getch();
	return 0;
}

int initQueue(quePtr *Q)
{
	(*Q)=(quePtr)malloc(sizeof(Queue));
	(*Q)->array=(char *)malloc(sizeof(char)*20);
	(*Q)->front=-1;
	(*Q)->rear=-1;	
}

int initStack(stackPtr *S)
{
	*S=(stackPtr)malloc(sizeof(Stack));
	(*S)->arr=(char *)malloc(sizeof(char)*20);
	
}
void enqueue(queuePtr, char);
void push(stackPtr, char);
char dequeue(queuePtr );
char pop(StackPtr );
void reverse(quePtr );
void display(quePtr );

