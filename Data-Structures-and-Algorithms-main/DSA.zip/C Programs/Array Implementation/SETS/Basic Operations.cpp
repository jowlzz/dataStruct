#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 20


typedef struct {
	int data[SIZE];
	int last;
}SET;

void initSet (SET *S);
void populateSet (SET *A, SET *B);
void insertData (SET *S, int elem);
SET Union (SET A, SET B);
SET Difference (SET A, SET B);
SET Intersection (SET A, SET B);
void display (SET S);

int main ()
{
	SET X;
	SET Y;
	SET R;
	
	initSet (&X);
	initSet (&Y);
	populateSet (&X, &Y);
	
	R=Union (X, Y);
	printf("\n Union Set: ");
	display (R);
	
	R=Difference (X, Y);
	printf("\n X-Y (Difference): ");
	display (R);
	
	R=Difference (Y, X);
	printf("\n Y-X (Difference): ");
	display (R);
	
	R=Intersection (X, Y);
	printf("\n Intersection Set: ");
	display (R);	
	
	getch();
	return 0;
}

void initSet (SET *S)
{
	S->last=-1;
}

void populateSet (SET *A, SET *B)
{
	int dataA[] = {1, 10, 17, 109, 100, 14, 19, 115, 104, 111};
 	int dataB[] = {105, 55, 45, 10, 15, 20, 100, 120, 15, 110};
 	int trav;
 	
 	for (trav=0;trav<10; trav++){
 		insertData (A, dataA[trav]);	
	}
	for (trav=0;trav<10; trav++){
 		insertData (B, dataB[trav]);	
	}
}

void insertData (SET *S, int elem)
{
	int temp;
	
	for (temp=0;temp<=S->last && S->data[temp]!=elem;temp++){}
	if(temp>S->last){
		S->data[S->last++]=elem;
	}	
	
}

SET Union (SET A, SET B)
{
	SET C;
	int trav, p;
	
	memcpy(C.data, A.data, sizeof(int)*(A.last));
	C.last=A.last;
	for (trav=0;trav<=B.last;trav++){
		for(p=0;p<=A.last && B.data[trav]!=A.data[p];p++){}
		if(p>A.last){
			C.data[C.last++]=B.data[trav];
		}
	}
	return C;
}

SET Difference (SET A, SET B)
{
	SET C;
	int trav, p;
	
	for (trav=0;trav<=A.last;trav++){
		for(p=0;p<=B.last && A.data[trav]!=B.data[p];p++){}
		if(p>B.last){
			C.data[C.last++]=A.data[trav];
		}
	}
	return C;	
}

SET Intersection (SET A, SET B)
{
	SET C;
	int trav, p;
	
	memcpy(C.data, A.data, sizeof(int)*(A.last));
	C.last=A.last;
	for (trav=0;trav<=B.last;trav++){
		for(p=0;p<=A.last && B.data[trav]!=A.data[p];p++){}
		if(B.data[trav]==A.data[p]){
			C.data[C.last++]=B.data[trav];
		}
	}
	return C;
}
void display (SET S)
{
	int trav;
	
	for (trav=0;trav<=S.last;trav++){
		printf("\n Data %d : %d", trav, S.data[trav]);
	}
}
