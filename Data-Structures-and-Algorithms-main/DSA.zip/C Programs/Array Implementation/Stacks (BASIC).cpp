#include<stdio.h>
#include<conio.h>
#include<stdlib.h>


typedef struct stack{
	int *elem;
	int top;
	int capacity;
} *STACK;

void initStack(STACK *);
void addElem(STACK);
void push(STACK, int newElem);
void pop(STACK);
void display(STACK);

int main()
{
    STACK A;
    char option;
    int newElem;
    
	initStack(&A);
	addElem(A);
	display(A);
	do{
		printf("\n Do you want to add an element(Y or N)? ");
		scanf("%c", &option);
		fflush(stdin);
		if (option=='Y'){
			printf("\n Enter the element you want to add: ");
			scanf("%d", &newElem);
			fflush(stdin);
	        push(A, newElem);
		}
	} 
	while (option!='N' && A->top<=A->capacity);
	display(A);
	
	do{
		printf("\n Do you want to remove an element(Y or N)? ");
		scanf("%c", &option);
		fflush(stdin);
		if (option=='Y'){
	        pop(A);
		}
	} 
	while (option!='N');
	display(A);
	getch();
	return 0;
}

void initStack(STACK *B)
{
	*B=(STACK)malloc(sizeof(STACK));
	(*B)->capacity=10;
	(*B)->elem=(int*)malloc(sizeof(int)*10);
	(*B)->top=-1;
}

void addElem(STACK B)
{
	int trav;
	    for(trav=0;trav<5;trav++){
	        printf("\n Add an element: ");
           	scanf("%d", &B->elem[trav]);
           	fflush(stdin);
        }
        B->top=trav-1;
}

void display(STACK B)
{
	int trav;
	printf("The number that serves as the top of the stack is: %d", B->top);
	printf("\n Current elements of stack: \n ");
	for(trav=B->top;trav!=-1;trav--){
		printf("\n %d", B->elem[trav]);
	}
}

void push(STACK B, int newElem)
{
	if(B->top==B->capacity){
		printf("\n The stack is full");
	} else {
		B->top++;
		B->elem[B->top]=newElem;
	}
}
void pop(STACK B)
{
	if(B->top!=-1){
			B->top--;		
		}
}
