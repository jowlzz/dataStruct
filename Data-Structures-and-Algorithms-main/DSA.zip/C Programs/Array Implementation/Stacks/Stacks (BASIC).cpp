#include<stdio.h>
#include<conio.h>
#include<stdlib.h>


typedef struct stack{
	int *elem;
	int top;
	int capacity;
} *STACK;

void initStack(STACK *);
void push(STACK, int newElem);
void pop(STACK);
void display(STACK);

int main()
{
    STACK A;
    char option;
    int newElem, choice;
    
	initStack(&A);
	do{
		printf("\n (1) Add \n (2)deleteNode \n Enter action (number only): ");
		scanf("%d", &choice);
		fflush(stdin);
	    switch(choice){
		    case 1: printf("\n Enter the number you want to add to the list: ");
				    scanf("%d", &newElem);
				    fflush(stdin);
				    push(A, newElem);
				    break;
		    case 2: pop(A);
				    break;
		    default: printf("Option not found");
				     display(A);
				     break;
		}
		printf("\n Do you want to continue? Y or N : ");
		scanf("%c", &option);
	}
	while (option=='Y'||option=='y' && A->top<A->capacity);
	display(A);
	getch();
	return 0;
}

void initStack(STACK *B)
{
	*B=(STACK)malloc(sizeof(STACK));
	(*B)->capacity=10;
	(*B)->elem=(int*)malloc(sizeof(int)*10);
	(*B)->top=-1;
}

void display(STACK B)
{
	int trav;
	printf("The number that serves as the top of the stack is: %d", B->top);
	printf("\n Current elements of stack: \n ");
	for(trav=B->top;trav!=-1;trav--){
		printf("\n %d", B->elem[trav]);
	}
}

void push(STACK B, int newElem)
{
	if(B->top==B->capacity){
		printf("\n The stack is full");
	} else {
		B->top++;
		B->elem[B->top]=newElem;
	}
}
void pop(STACK B)
{
	if(B->top!=-1){
			B->top--;		
		}
}
