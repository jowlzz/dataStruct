#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef int SET [10];

SET *Union (SET A, SET B);
SET *Intersection(SET A, SET B);
SET *Difference (SET A, SET B);
void printSet(SET S);

int main ()
{
	SET A ={1,0,1,1,0,0,0,1,0,1};
	SET B ={1,0,0,0,1,1,0,1,0,0};
	SET *C, R;
	
	
	printf("\n First Set: SET A");
	printSet(A);
	printf("\n Second Set: SET B");
	printSet(B);
	C=Union(A, B);
	printf("\n Union Set");
	printSet(*C);
	C=Intersection(A, B);
	printf("\n Intersection Set");
	printSet(*C);
	C=Difference(A, B);
	printf("\n Difference Set: A-B");
	printSet(*C);
	C=Difference(B, A);
	printf("\n Difference Set: B-A");
	printSet(*C);
	getch();
	return 0;
}

SET *Union (SET A, SET B)
{
	SET *combAB;
	int trav;
	
	combAB=(SET *)malloc(sizeof(SET));
	for(trav=0;trav<10;trav++){
		if(A[trav]==1||B[trav]==1){
			(*combAB)[trav]=1;
		} else {
			(*combAB)[trav]=0;
		}
	}
	return combAB;
}

SET* Intersection(SET A, SET B)
{
	SET *commonAB;
	int trav;
	
	commonAB=(SET *)malloc(sizeof(int)*10);
	for(trav=0;trav<10;trav++){
		(*commonAB)[trav]=((A[trav]==1 && B[trav]==1)?1:0);
	}
	return commonAB;	
}
SET* Difference (SET A, SET B)
{
	SET *diffAB;
	int trav;
	
	diffAB=(SET *)malloc(sizeof(int)*10);
	for(trav=0;trav<10;trav++){
		(*diffAB)[trav]=((A[trav]==1&&B[trav]==0)?1:0);
	}
	return diffAB;
}

void printSet(SET S)
{
	int trav;
	printf("\n Elements of the Set are : \n {");
	for(trav=0;trav<10;trav++){
		if(S[trav]==1){
			printf(" %d, ", trav);
		}
	}
	printf("}");
}
