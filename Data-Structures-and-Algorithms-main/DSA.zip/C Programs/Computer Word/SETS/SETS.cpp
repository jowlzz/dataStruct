#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef unsigned char SET;

SET UNION(SET A, SET B);
SET INTERSECTION (SET A, SET B);
SET DIFFERENCE (SET A, SET B);
void printSet(SET C);

int main ()
{
	SET X = 9;
	SET Y = 26;
	SET R;
	
	printf("\n The first set contains: ");
	printSet(X);
	printf("\n The second set contains: ");
	printSet(Y);
	R=UNION(X, Y);
	printf("\n Union Set");
	printSet(R);
	R=INTERSECTION(X, Y);
	printf("\n Intersection Set");
	printSet(R);
	R=DIFFERENCE(X, Y);
	printf("\n Difference Set");
	printSet(R);	
	getch();
	return 0;
}

SET UNION(SET A, SET B)
{
	SET C;
	
	C=A|B;

	return C;
}
SET INTERSECTION (SET A, SET B)
{
	SET C;
	
	C=A&B;
	
	return C;
}

SET DIFFERENCE (SET A, SET B)
{
	SET C;
	
	C=A&~B;
	
	return C;
}
void printSet(SET C)
{
	unsigned mask;
	int ctr;
	
	printf("\n");
	printf("{ ");
	
	mask = 1 << (sizeof(char)*8)-1;
	
	for (ctr=(sizeof(char)*8)-1; ctr > -1 ; ctr--){
		if (C & mask) {
			printf("%d,", ctr);
		} 
		mask >>= 1;
	}
	printf(" }");
}
