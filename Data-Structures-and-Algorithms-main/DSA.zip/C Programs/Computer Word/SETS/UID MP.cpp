/*******************************************************************************
 * CS/IT 126 Machine Problem 1 : ADT UID                                       *
 * *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include<conio.h>
#include <string.h>
#define LIST_SIZE    1000

/* Delete these macro definition if your will not use this in your program*/
#define MASK_CS   		0X40
#define MASK_IT   		0X80
#define MASK_ICT     	0XC0
#define MASK_FEMALE  	0X04


/******************************************************************************
 * Data Structure Definition: Array and Linked List Implementation            *
 ******************************************************************************/
/*Definition of the records */ 
typedef struct { 
   char fName[24];    /* firstname */
   char lName[16];    /* lastname */
   char  mi;          /* middle initial */ 
}nameType; 

typedef struct {
   char ID[9]; 
   nameType name; 
   char course[8]; 
   int year; 
   char gender;        /* F - female, M-male */
   unsigned char elective;   /* each of the 8 bits represents an elective course,
                                 value of 1 indicates that student has passed the course, 0 - not passed */ 
   char acadStatus;    /* 1 - Okay, 2 - Probationary, 3 - *Okay (Lifted Probation) */
}studRec; 

/* Definition of records in the file */
typedef struct { 
   char ID[9];
   nameType name; 
   unsigned char elective;
   unsigned char zipData;    /* implemented using computer word,  
                                from Left to Right bits: Status - 2 bits, Gender - 1 bit, course - 2 bits, year - 3 bits */            
}fileRec; 

/***********************************************************
 * Array implementation of list of Student Records         * 
 **********************************************************/
typedef struct arr{ 
   studRec students[LIST_SIZE]; 
   int last;    /* index of the last element */               
}*List;         /* Version 2 */

/***********************************************************
 * Linked list implementation of list of fileRec Records   * 
 **********************************************************/
struct fileList{
	fileRec frec;
	struct fileList *next;
};


/**********************************************************
 * Function Prototypes                                    *
 *********************************************************/

/* Array List Function Prototypes: For Question #1  */ 
void initializeList(List *A);                  
void populateSortedList(List L);        
void insertSortedID(List L, studRec S);
void displayArrayList(List L, char *listDesc);           
int getNumberOfElectives(unsigned char elective);        

/* Linked List Function Prototypes */ 
unsigned char createZipData(studRec stud);
struct fileList * createSortedFileList(List L);     
void displayLinkedList(struct fileList *L, char *listDesc);    
void displayFileRec(fileRec f);
														 

/* Files */
void createFile(struct fileList *A);
struct fileList * createListIDFromFile();                

char * getCourse(fileRec f);
int getYear(fileRec f);
char getGender(fileRec f);
int getStatus(fileRec f);
void displayStudentInfo(fileRec f);                
void displayStudentList(struct fileList *L, char *listDesc); 
															

int main( ) 
{	
           /* Put all variable declarations HERE */
            List L;
           struct fileList *A, *B;
           char desc[100];

 /*----------------------------------------------------------------------------
 * To facilitate the checking of the program, follow the instructions in each
 * number. To accomplish the task for each number, a series of function calls
 * may be needed. 
 *  
 *  WRITE YOUR ANSWER BELOW THE NUMBERED COMMENTS. DO NOT DELETE COMMENTS
 * ---------------------------------------------------------------------------*/    
 
 			initializeList(&L);               
 
/*   #1]  A sorted list of student records represented using array implementation is created. 
          The list is sorted in ascending order according to ID.  
          All student information are displayed on screen by calling displayArrayList(). */
          populateSortedList(L);
          strcpy(desc, "Student Records represented in array implementation");
          displayArrayList(L, desc);
 
 	
/*   #2]  A sorted list of file records implemented using linked list is created. 
         The list is sorted in ascending order according to lastnames.
         All file record information are displayed on screen by calling displayLinkedList(). */
         A=createSortedFileList(L);
         strcpy(desc, "Student Records represented in Linked List implementation");
         displayLinkedList(A, desc);
         
 
	
/*   #3]  Create a file containing records of type fileRec name CSIT126students.dat */	
 
	
/*   #4]  Read the file of records name CSIT126students.dat and create a list of fileRec records implemented 
         using linked list. The newly created list is sorted according to ID. Call displayLinkedList() */	
 

/*   5]  Using the list created in Q4 (linked list), display the all student record information:
         ID, name, course and year, gender, and academic status. */ 
 
 	
	
	getch();
	return 0;
}

/************************************************************
 *   Function Definition for #1                                                                               *
 ************************************************************/
void initializeList(List *A)
{
	*A=(List)malloc(sizeof(arr));
	(*A)->last=-1;	
}                   

void insertSortedID(List L, studRec S)
{
	int p;
	
	if(L->last<LIST_SIZE){
		for(p=0;L->students[p].ID < S.ID && p <= L->last;p++){}
		memcpy(L->students+(p+1), L->students+p, sizeof(studRec)*((L->last++)-p+1));
		L->students[p]=S;
	}
}      
   
int getNumberOfElectives(unsigned char elective)
{
	int num, cnt;
	unsigned char mask;
	
	cnt=0;
	mask=1<<(sizeof(char)*8)-1;
	for(num=7;num>-1;num--){
		if(mask & elective){
			cnt++;
		}
		mask>>=1;
	}	
	return cnt;
} 

void populateSortedList(List L)
{
	int x, num;
	
	studRec data[] = { 	{"12104029", {"Mary Grace", "Tan", 'A'}, "BSCS", 4, 'F', 0xAB, 1},
                    	{"14100686", {"John Joseph", "Mendoza", 'B'}, "BSCS", 2, 'M', 0x33, 2},
						{"13101813", {"Bernardina", "Velasco", 'C'}, "BSCS", 3, 'F', 0x2F, 3},
						{"14101125", {"Faith Therese", "Flores", 'D'}, "BSCS", 2, 'F', 0x57, 1},
						{"15102468", {"Ryan Christian", "Mercado", 'E'}, "BSCS", 1, 'M', 0x1A, 2},
						{"15104179", {"Simon Peter", "Amolo", 'F'}, "BSIT", 1, 'M', 0x05, 1},
						{"15103188", {"Mikee", "Seno", 'G'}, "BSIT", 1, 'F', 0x0B, 1},
						{"14104110", {"Tom Christian", "Fernandez", 'H'}, "BSIT", 2, 'M', 0x07, 2},
						{"13101813", {"Janine Angela", "Ang", 'I'}, "BSIT", 3, 'F', 0x2F, 3},
						{"12102385", {"Hans Christian", "Anderson", 'J'}, "BSIT", 4, 'M', 0xFF, 3},
						{"15102424", {"Albert John", "Baguio", 'K'}, "BSICT", 1, 'M', 0x05, 1},
						{"12107777", {"Antonette Marie", "Lee", 'L'}, "BSICT", 4, 'F', 0xFF, 1},
						
						
	};
    num = 12;
 
    for(x = 0; x < num; x++){
    	insertSortedID(L, data[x]);
	}
	
}


void displayArrayList(List L, char *listDesc)
{
	int x;
	char name[80];
	studRec stud;
	
	system("cls");
	printf("\n%s", listDesc);
	printf("\n--------------------\n");
	printf("\n%-10s","ID");
	printf("%-30s","Name");
	printf("%-15s","Course & Year");
	printf("%-7s","Gender");
	printf("%-9s","Elective");
	printf("%-5s","Status");
	

    printf("\n");
    for(x = 0; x <= L->last; x++){
    	stud = L->students[x];
    	printf("\n%-10s",stud.ID);
    	sprintf(name, "%s, %s %c.", stud.name.lName, stud.name.fName, stud.name.mi);
		printf("%-30s",name);
		printf("%-9s %-6d", stud.course, stud.year );
		printf("%-7c",stud.gender);
	     
		printf("%-9d",getNumberOfElectives(stud.elective));    
		printf("%-5d",stud.acadStatus);

	}
    printf("\n\nPress any key to continue...  ");
    getch();

}


 
/***********************************************************
 *   Function Definition for #2    (Linked List)                                                     *
 ***********************************************************/
 
unsigned char createZipData(studRec stud)
{
	unsigned char info;
	
	info=stud.year+(stud.gender=='F'?16:0)+stud.acadStatus*64;
	
	if(strcmp(stud.course,"BSCS")==0){
		info += 0x08;
	} else if (strcmp(stud.course, "BSIT")==0){
		info += 0x10;
	} else {
		info += 0x18;
	}
	
	return info;
}

struct fileList * createSortedFileList(List L)
{
	struct fileList **tail, *A, *temp;
	int trav;
	
	A=NULL;
	tail=&A;
	for(trav=0;trav<=L->last;trav++){
		for((*tail)=A;strcmp((*tail)->frec.name.lName, L->students[trav].name.lName)<0 && *tail!=NULL;tail=&(*tail)->next){}
		temp=(struct fileList *)malloc(sizeof(struct fileList));
		if(temp!=NULL){
			printf("P");
			strcpy(temp->frec.name.lName, L->students[trav].name.lName);
			strcpy(temp->frec.name.fName, L->students[trav].name.fName);
			temp->frec.name.mi=L->students[trav].name.mi;
			strcpy(temp->frec.ID,L->students[trav].ID);
			temp->frec.elective=L->students[trav].elective;
			temp->frec.zipData = createZipData (L->students[trav]);
			temp->next=*tail;
			*tail=temp;
		} 
	}
	return A;
}        

void displayFileRec(fileRec f)
{
	printf("%-10s", f.ID);
	printf("%-30s , %s %c.", f.name.lName, f.name.fName, f.name.mi);
	printf("%-10s", f.zipData);
	printf("%-9s", getNumberOfElectives(f.elective));
	
}
void displayLinkedList(struct fileList *L, char *listDesc)
{
	char name[80];
		
	system("cls");
	printf("\n%s", listDesc);
	printf("\n--------------------\n");
	printf("\n%-10s","ID");
	printf("%-30s","Name");
	printf("%-10s","Zip Data");
	printf("%-9s","Elective");


    printf("\n");
    for(  ;  L!= NULL ; L = L->next){
        	displayFileRec(L->frec);
   }  
   printf("\n\nPress any key to continue... ");
   getch();
}

/********************************************************
 * For Question # 3                                     *
 *******************************************************
 
void createFile(struct fileList *A)
{
	FILE *ptr;
	
	ptr=fopen("CSIT126students.dat", "wb");
	if (ptr!=NULL){
		for(;A!=NULL;A=A->next){
			fwrite(&(A->frec), sizeof(fileRec), 1, ptr);
		}
	}
	fclose(ptr);
}
/********************************************************
 * For Question # 4                                     *
 *******************************************************
struct fileList * createListIDFromFile()
{
	struct fileList *A, **tail, *temp;
	FILE *fptr;
	
	A=NULL;
	tail=&A;
	
	fptr=fopen("CSIT126students.dat", "wb");
	while (fptr){
		temp=(struct fileList *)malloc(sizeof(struct fileList));
		if(temp!=NULL){
			fread(temp, sizeof(fileRec), 1, fptr);
			for(*tail=A;tail!=NULL&&strcmp((*tail)->frec.ID, temp->frec.ID)<0;tail=&(*tail)->next){}
			temp->next=*tail;
			*tail=temp;
		}
	}
	fclose(fptr);
}

********************************************************
 * For Question # 5                                     *
 *******************************************************
char * getCourse(fileRec f)
{
	char course[8];
	unsigned char mask;
	

}

int getYear(fileRec f)
{
	
}
char getGender(fileRec f);
int getStatus(fileRec f);
void displayStudentInfo(fileRec f);   
void displayStudentList(struct fileList *L, char *listDesc)
{
     fileRec f;
     
    system("cls");
	printf("\n%s", listDesc);
	printf("\n--------------------\n");
	printf("\n%-10s","ID");
	printf("%-30s","Name");
	printf("%-15s","Course & Year");
	printf("%-7s","Gender");
	printf("%-9s","Elective");
	printf("%-5s","Status");
	

    printf("\n");
    for(  ; L != NULL; L = L->next){
       displayStudentInfo(L->frec);
    }
    
    printf("\n\nPress any key to continue...  ");
    getch();


}
*/


