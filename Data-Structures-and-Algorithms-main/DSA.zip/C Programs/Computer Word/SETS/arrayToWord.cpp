#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>

typedef unsigned char SET;

SET arrayToWord (SET *S);
void displaySet (SET S);

int main ()
{
	SET A[] = {7, 4, 0, 2};
	SET C;
	
	C=arrayToWord (A);
	displaySet (C);
	getch();
	return 0;
}

SET arrayToWord (SET *S)
{
	SET R;
	int cnt;
	
	R=0;
	for(cnt=0;cnt<4;cnt++){
		R=R+pow(2, S[cnt]);
	}
	
	return R;
}

void displaySet (SET S)
{
	unsigned mask;
	int cnt;
	
	printf("\n In computer word the set is: %u", S);
	
	mask = 1 << (sizeof(char)*8)-1;
	printf("\n { ");
	for (cnt=sizeof(char)*8-1;cnt>-1;cnt--){
		if(mask & S){
			printf("%d, ", cnt);
		}
		mask >>=1;
	}
	printf("}");
}
