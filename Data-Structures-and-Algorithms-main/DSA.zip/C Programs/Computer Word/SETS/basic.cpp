#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef char SET;

void insert(SET *A, int elem);
void deleteElem (SET *A, int elem);
void display (SET A);
void displayElem (SET A);

int main ()
{
	SET X=0;
	int elem, op;
	char choice;
	
	do {
		printf("\n (1) Insert \n (2) Delete \n (3) Display \n Choose: ");
		scanf("%d",&op);
		fflush(stdin);
		switch(op)
		{
			case 1: printf("\n Enter the element you want to insert in the set: ");
					scanf("%d", &elem);
					fflush(stdin);
					insert (&X, elem);
					break;
			case 2: printf("\n Enter the element you want to delete in the set: ");
					scanf("%d", &elem);
					fflush(stdin);
					deleteElem (&X, elem);
					break;
			default: display (X);
		}
		printf("\n Do you want to continue?(Y or N) : ");
		scanf("%c", &op);
		fflush(stdin);
	} while (op=='Y'||op=='y');
	
	displayElem(X);
	getch();
	return 0;
}

void insert(SET *A, int elem)
{
	unsigned char mask;
	
	mask=1<<(sizeof(char)*elem);
	*A= *A|mask;
}

void deleteElem (SET *A, int elem)
{
	unsigned char mask;

	mask=1<<(sizeof(char)*elem);
	/*if(mask & *A){
		*A ^= mask;
	}*/
	*A=(*A)&~mask;
}

void display (SET A)
{
	unsigned char mask;
	int ctr;
	mask = 1<<((sizeof(char)*8)-1);
	printf("\n The set in computer word: %d", A);
	printf("\n In binary: ");
	
	for(ctr=0;ctr<sizeof(char)*8;ctr++){
		(A & mask)?printf("1"):printf("0");
		mask>>=1;
	}
}

void displayElem (SET A)
{
	unsigned char mask;
	int ctr;
	
	mask = 1<<((sizeof(char)*8)-1);
	printf("\n Elements in set: ");
	
	for(ctr=7;ctr>-1;ctr--){
		if(A&mask){
			printf("%d, ", ctr);
		} 
		mask>>=1;
	}
}
