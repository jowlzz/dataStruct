#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>

typedef unsigned char SET;

SET getEven (SET S);
void displaySet(SET S);

int main()
{
	SET A=67;
	SET C;
	
	printf("\n Set A");
	displaySet(A);
	C=getEven (A);
	printf("\n Even subset of Set A");
	displaySet (C);
	
	getch();
	return 0;
}

SET getEven (SET S)
{
	int cnt;
	unsigned mask;
	SET R;
	
	R=0;
	mask=1 << (sizeof(char)*8)-2;
	
	for (cnt=6;cnt>-1;cnt-=2){
		if(mask&S){
			R=R+pow(2,cnt);
		}
		mask>>=2;
	}
	return R;
}

void displaySet(SET S)
{
	unsigned mask;
	int ctr;
	
	printf("\n In computer word: %u", S);
	mask = 1 << (sizeof(char)*8)-1;
	printf("\n { ");
	for(ctr=7;ctr>-1;ctr--){
		if(mask&S){
			printf("%d, ",ctr);
		}
		mask>>=1;
	}
	printf("}");
}
