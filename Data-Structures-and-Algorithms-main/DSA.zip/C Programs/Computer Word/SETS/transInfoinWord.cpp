#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

typedef unsigned char SET;

typedef struct {
	int year;
	char gender;
	char course[20];
}student;

SET infoInWord (student A);
void displayBinary (SET A);

int main ()
{
	SET C;
	int ctr;
	student S []={{3, 'F', "BSIT"},
				  {1, 'F', "BSCS"},
				  {4, 'M', "BSCS"},
				  {2, 'F', "ACTMT"},
				  {3, 'M', "BSIT"},
				  {4, 'M', "BSICT"},
				  {2, 'M', "ACTMT"},
				  {1, 'F', "BSICT"},
				 };
	for (ctr=0;ctr<8;ctr++){
		C=infoInWord(S[ctr]);
		displayBinary (C);
		printf("\n Year Level: %d", S[ctr].year);
		printf("\n Gender (F or M): %c", S[ctr].gender);
		printf("\n Course: %s", S[ctr].course);
	}
	getch();
	return 0;
}

SET infoInWord (student A)
{
	SET R;
	R=0;
	int crs;
	
	R=(A.gender=='F'?1:0) + (A.year * 2);
	
	if (strcmp(A.course, "BSIT")==0){
		R += 0x10;
	} else if (strcmp(A.course, "BSCS")==0){
		R += 0x20;
	} else if (strcmp(A.course, "ACTMT")==0){
		R += 0x30;
	} else {
		R += 0x40;;
	}
	
	
	return R; 
	
}
void displayBinary (SET A)
{
	unsigned mask;
	int ctr;
	
	printf("\n \n Info in computer word: %u", A);
	mask = 1 << (sizeof(char)*8)-1;
	
	printf("\n In Binary: ");
	for(ctr=7;ctr>-1;ctr--){
		if(mask&A){
			printf("1");
		} else {
			printf("0");
		}
		mask >>=1;
	}
	
}
