/******************************************************************
* Project Name: BST application in Cursor-Based implementation *
* Programmer : Ventura, Jane Colleen T. *
* Date Completed: August 3, 2015 *
******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/******************************************************************
* Data Structure Definition *
******************************************************************/

#define HEAPSIZE 15
typedef struct {
    unsigned int prodID; /* product ID*/
 	char prodDesc[15]; /* product description*/
 	float prodPrice; /* product price*/
 	int prodQty; /* product count or quantity */
}product; /* product record */
typedef struct {
 	product item;
 	int LC; /* Left Child Pointer; USE TO LINKED AVAILABLE nodes; -1 if not pointing to anything */
 	int RC; /* Right Child Pointer; -1 if not pointing to anything */
} bstNode;
typedef struct {
 	bstNode Heap[HEAPSIZE];
 	int Avail; /* Points to the first available node in the virtual Heap */
}virtualHeap; /* Definition of Virtual Heap */
typedef int BST; /* Definition of Binary Search Tree */
/******************************************************************
* Function Prototypes *
******************************************************************/
void initializeVHeap(virtualHeap *V);
void displayVHeap(virtualHeap V);
int allocSpace(virtualHeap *V);
void deallocSpace(virtualHeap *V, int ndx);
void initializeBST(BST *B);
void populateBST(BST *B, virtualHeap *V);
void insertBST(BST *B, virtualHeap *V, product X);
void displayBST(BST B, virtualHeap V);
void deleteBST(BST *B, virtualHeap *V, product X);

int main(void)
{
	virtualHeap VH;
	BST B;
 /* populateBST() is called to put elements in the BST.
 Use the data provided in populateBST to verify the correctness of the function.
 DELETE THIS COMMENT!!
 */
	return 0;
}
void initializeVHeap(virtualHeap *V)
{
	int ctr;
	
	for(ctr = 0;ctr < HEAPSIZE;ctr++){
		V->Heap[ctr].LC = p-1;
		V->Heap[ctr].RC = 1000;
		V->Heap[ctr].item.prodID = 0;
	}
	V->Avail=HEAPSIZE - 1;
	
}

int allocSpace(virtualHeap *V)
{
	int p;
	
	p=V->Avail;
	if(p!=-1){
		V->Avail = V->Heap[p].LC;
	}
	return p;
}

void deallocSpace(virtualHeap *V, int ndx)
{
	if(ndx!=-1 && ndx<HEAPSIZE){
		V->Heap[ndx].LC=V->Avail;
		V->Avail=ndx;
	}
}

void initializeBST(BST *B)
{
	*B=-1;
}
void populateBST(BST *B, virtualHeap *V)
{
	int x;
	product data[] = { {1501, "Hersheys", 100.50, 10},
					   {1701, "Toblerone", 150.75, 20},
				   	   {1550, "Cadbury", 200.00, 30},
				   	   {1201, "Kitkat", 97.75, 40},
				   	   {1450, "Ferrero", 150.50, 50},
				   	   {1601, "Meiji", 75.50, 60},
				   	   {1301, "Nestle", 124.50, 70},
				   	   {1525, "Lindt", 175.50, 80},
				   	   {1545, "Valor", 100.50, 90},
				   	   {1455, "Tango", 49.50, 100}
 				 	 };
    for(x = 0; x < 10; x++){
 	    insertBST(B, V, data[x]);
	}
}

void displayVHeap(virtualHeap V)
{
    int ndx;
	printf("\nContents of the Virtual Heap");
	printf("\n\nAvail : %d", V.Avail);
	printf("\n%5s%15s%10s%10s","Index","Product ID","LC","RC");
	for(ndx = 0; ndx < HEAPSIZE; ndx++){
		printf("\n%5d", ndx);
		printf("%15d", V.Heap[ndx].item.prodID);
		printf("%10d", V.Heap[ndx].LC);
		printf("%10d", V.Heap[ndx].RC);
	}
 	printf("\n\nPress any key to continue... ");
 	getch();
} 

void insertBST(BST *B, virtualHeap *V, product X)
{
	int ndx, trav;
	if (V->Avail>=0){
		ndx=allocSpace(V);
		V->Heap[ndx].item=X;
		for(trav=*B; trav!=-1)
		
	}
}
void displayBST(BST B, virtualHeap V);
void deleteBST(BST *B, virtualHeap *V, product X);
