#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include SIZE 10

typedef struct{
	int num;
	int right;
	int left;
}heapContent;

typedef heapContent HeapSpace[SIZE];

typedef struct{
	HeapSpace HS;
	int avail;
}vHeap;

typedef int listType;

void initList(listType *L);
void initVirtHeap(vHeap *VH);
void insertContent(vHeap *VH, listType *L, int data);
int allocSpace(vHeap *VH);
int deleteContent(vHeap *VH, listType *L, int data);
int deleteMin(vHeap *VH, listType *L);
int deleteMax(vHeap *VH, listType *L);
int findMax(vHeap VH, listType L);
int findMin(vHeap VH, listType L);
void deallocSpace(vHeap *VH, int ndx);
void preorderPrint(vHeap VH; listType L);
void postoderPrint(vHeap VH; listType L);
void inorderPrint(vHeap VH; listType L);

int main()
{
	vHeap V;
	listType B;
	int node, op, delNode;
	char choice;
	
	initList(&B);
	initVirtHeap(&V);
	
	do {
		printf("\n (1)Insert (2)Delete (3)Delete Minimum (4) Delete Maximum (5) Display \n Choose an action: ");
		scanf("%d", &op);
		switch(op){
			case 1: printf("\n Enter the number you want to enter in the tree: ");
					scanf("%d", &node);
					insertContent(&V, &B, node);
					break;
			case 2: printf("\n Enter the number you want to delete: ");
					scanf("%d", &node);
					delNode=deleteContent(&V, &B, node);
					printf("\n The deleted node is :%d", delNode);
					break;
			case 3: delNode=deleteMin(&V, &B);
					printf("\n The node(smallest value) deleted is :%d", delNode);
					break;
			case 4: delNode=deleteMax(&V, &B);
					printf("\n The node(biggest value) deleted is :%d", delNode);
					break;
			case 5: preorderPrint(V, B);
					postorderPrint(V, B);
					inorderPrint(V, B);
					break;
			default: inorderPrint(V, B);
		}
		printf("\n Do you want to add more (Y or N)? ");
		scanf("%c", &choice);
	} while(choice=='Y'||choice=='y');
	
	getch();
	return 0;
}

void initList(listType *L)
{
	*L=-1;
}

void initVirtHeap(vHeap *VH)
{
	int p;
	
	for(p=0;p<SIZE;p++){
		VH->HS[p].right=-1;
		VH->HS[p].left=-1;
	}
}
void insertContent(vHeap *VH, listType *L, int data);
int allocSpace(vHeap *VH);
int deleteContent(vHeap *VH, listType *L, int data);
int deleteMin(vHeap *VH, listType *L, int data);
int deleteMax(vHeap *VH, listType *L, int data);
int findMax(vHeap VH, listType L);
int findMin(vHeap VH, listType L);
void deallocSpace(vHeap *VH, int ndx);
void preorderPrint(vHeap VH; listType L);
void postoderPrint(vHeap VH; listType L);
void inorderPrint(vHeap VH; listType L);

