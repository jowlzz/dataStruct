#include<stdio.h>
#inlude<conio.h>
#include<stdlib.h>
#define MAX 100

typedef struct{
	int label;
	int left;
	int right;
}vHeap;
typedef struct{
	vHeap *nodes;
	int avail;
}TREE;

typedef int head;

void initTree(TREE *, head*);
void initVHeap(TREE *);
void dealloc(TREE *, int);
int allocSpace(TREE *);
int Search (int, TREE, head);
void deleteNode(TREE *, int node, head*);
int deleteMin(TREE *,head*);
void insertNode(int value, TREE *, head*);
void preorderPrint(TREE, head);
void postOrderPrint(TREE, head);
void inorderPrint(TREE, head);

int main ()
{
	TREE root;
	char option;
	int data, action, top;
	initTree(&root, &top);
	initVHeap(&root);
	do{
		printf("\n (1) Insert\n(2) Delete Node\n(3) Print\n(4)Search \nEnter number of action: ");
		scanf("%d", &action);
		fflush(stdin);
		switch(action){
			case 1: printf("\n Enter data you want to insert: ");
					scanf("%d", &data);
					fflush(stdin);
					insertNode(data, &root, &top);
					break;
			case 2: printf("\n Enter data of node you want to delete: ");
					scanf("%d", &data);
					fflush(stdin);
					deleteNode(&root, data, &top);
					break;
			case 3:	printf("\n In order display");
					inorderPrint(root, top);
					break;
			case 4: printf("\n Enter the data you want to search for: ");
					scanf("%d", &data);
					fflush(stdin);
					if(Search(data, root, top)==1){
						printf("\n The data exists in the tree.");
					} else {
						printf("\n The data does not exist in the tree");
					}
					break;
			default: printf("\n Invalid choice");
		}
		printf("\n Do you want to continue? (Y or N)");
		scanf("%c",&option);
		fflush(stdin);
	} while (option=='Y'||option=='y');
	
	printf("\n Preorder Display");
	preorderPrint(root, top);
	printf("\n Post Order Display");
	postOrderPrint(root, top);
	printf("\n In order Display");
	inorderPrint(root, top);
	getch();
	return 0;
}

void initTree(TREE *R, head *T)
{
	R->nodes=(vHeap *)malloc(sizeof(vHeap)*MAX);
	*T=-1;
}

void initVHeap(TREE *R)
{
	int p;
	for(p=0;p<MAX;p++){
		R->nodes[p].left=R->nodes[p].right=-1;
	}
	V->avail=MAX-1;
}

int Search (int elem, TREE R, head T)
{
	int retVal;
	retVal=0;
	if(T!=-1){
		while((R->nodes[T].left!=-1&&R->nodes[T].right!=NULL)&&R->nodes[T].label==elem){
			R->nodes[T].label<elem?T=R->nodes[T].right:T=R->nodes[T].left;
		}
		if(R->nodes[T].label==elem){
			retVal=1;
		}
	}
	return retVal;
}
void deleteNode(TREE *R, int node, head *T)
{
	head *trav, temp;
	
	if(*T!=-1&&Search(node, *R, *T)==1){
		trav=T;
		while(*trav!=-1&&R->nodes[trav].label!=node){
			R->nodes[*trav].label<node?trav=&(R->nodes[*trav].right):trav=&(R->nodes[*trav].left);
		}
		if(*trav!=-1){
			if(R->nodes[*trav].left!=-1&&R->nodes[*trav].right!=-1){
				R->nodes[*trav].label=deleteMin(R, trav);
			} else {
				temp=*trav;
				R->nodes[*trav].left!=-1?*trav=R->nodes[*trav].left:*trav=R->nodes[*trav].right;
				dealloc(temp, R);
			}
		}
	} else {
		printf("\n The element does not exist");
	}
}

void dealloc(TREE *R, int idx)
{
	if(idx>-1){
		R->nodes[idx].left=R->nodes[idx].right=-1;
		R->avail=idx;
	}
}

int allocSpace(TREE *R)
{
	int rVal;
	if(R->avail>-1){
		rVal=R->avail;
		R->avail
	}
}
int deleteMin(TREE *, head *);
void insertNode(int value, TREE *);
void preorderPrint(TREE);
void postOrderPrint(TREE);
void inorderPrint(TREE);
