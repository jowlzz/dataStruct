#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define HEAPSIZE 20

typedef struct {
    unsigned int prodID; 
 	char prodDesc[15]; 
	float prodPrice;
 	int prodQty; 
}prodDet;

typedef struct{
	prodDet data;
	int next;
}HeapSpace;

typedef HeapSpace VHeap [HEAPSIZE];
 
typedef struct{
	VHeap H;
	int avail;	
}virtHeap;


typedef enum {TRUE, FALSE}boolean;
typedef int List;

void initList (List *A);
void initHeap (virtHeap *VH);
int allocSpace (virtHeap *VH);
void deallocSpace (virtHeap *VH, int ndx);
boolean isExist (virtHeap VH, unsigned int ID, List A);
void insertSorted (virtHeap *VH, List *A, prodDet X);
prodDet deleteFirst (virtHeap *VH, List *A);
prodDet Search(virtHeap VH, List A, unsigned int ID);
void deleteProd (virtHeap *VH, List *A, prodDet X);
void displayAll (virtHeap VH, List A);
void productDisplay(virtHeap VH, List A, prodDet X);
void populate(List *B, virtHeap *V);

int main ()
{
	List X;
	virtHeap V;
	int choice;
	prodDet product, ret;
	char option;
	
	initList(&X);
	initHeap(&V);
	populate(&X, &V);
	do {
		printf("\n(1)InsertSorted \n(2)DeleteFirst \n(3)DeleteProd \n(4)Display Single Product \n(5)Display All products");
		printf("\n Enter the number of function: ");
		scanf("%d", &choice);
		fflush(stdin);
		switch(choice){
			case 1: printf("\n Enter product ID: ");
					scanf("%d", &product.prodID);
					fflush(stdin);
					printf("\n Enter product Description: ");
					scanf("%s", &product.prodDesc);
					fflush(stdin);
					printf("\n Enter product price: ");
					scanf("%f", &product.prodPrice);
					fflush(stdin);
					printf("\n Enter quantity of product: ");
					scanf("%d", &product.prodQty);
					fflush(stdin);
					insertSorted(&V, &X, product);
					break;				
			case 2: ret = deleteFirst(&V, &X);
					printf("\n The product deleted: ");
					productDisplay(V, X, ret);
					break;
			case 3: printf("\n Enter product ID of the product you want to delete : ");
					scanf("%d", &product.prodID);
					fflush(stdin);
					ret=Search(V, X, product.prodID);
					deleteProd(&V, &X, ret);
					fflush(stdin);
					break;
			case 4: printf("\n Enter product ID of product you want to display: ");
					scanf("%d", &product.prodID);
					fflush(stdin);
					ret=Search(V, X, product.prodID);
					productDisplay(V, X, ret);
					break;
			case 5: displayAll(V, X);
					break;
			default: printf("\n Invalid option");
		}
		printf("\n Do you want to continue (Y or N)? ");
		scanf("%c", &option);
		fflush(stdin);
	} while (option=='Y'||option=='y');
	
	displayAll(V, X);
	return 0;
}

void populate(List *B, virtHeap *V)
{
	int x;
	prodDet data[] = { {1501, "Hersheys", 100.50, 10},
					   {1701, "Toblerone", 150.75, 20},
				   	   {1550, "Cadbury", 200.00, 30},
				   	   {1201, "Kitkat", 97.75, 40},
				   	   {1450, "Ferrero", 150.50, 50},
				   	   {1601, "Meiji", 75.50, 60},
				   	   {1301, "Nestle", 124.50, 70},
				   	   {1525, "Lindt", 175.50, 80},
				   	   {1545, "Valor", 100.50, 90},
				   	   {1455, "Tango", 49.50, 100}
 				 	 };
    for(x = 0; x < 10; x++){
 	    insertSorted(V, B, data[x]);
	}
}

void initList (List *A)
{
	*A=-1;
}

void initHeap (virtHeap *VH)
{
	int trav;
	
	for(trav=0;trav<HEAPSIZE;trav++){
		VH->H[trav].next = trav-1;
	}
	VH->avail = HEAPSIZE-1;
}

int allocSpace (virtHeap *VH)
{
	int temp;
	
	temp=VH->avail;
	if(temp > -1){
		VH->avail = VH->H[temp].next;
	}
	return temp;
}

void deallocSpace (virtHeap *VH, int ndx)
{
	if(ndx > -1 && ndx < HEAPSIZE){
		VH->H[ndx].next = VH->avail;
		VH->avail=ndx;
	}
}

boolean isExist (virtHeap VH, unsigned int ID, List A)
{
	for(;VH.H[A].data.prodID!=ID && A>-1; A=VH.H[A].next){}
	return (A!=-1?TRUE:FALSE);	
}

prodDet Search(virtHeap VH, List A, unsigned int ID)
{
	prodDet retProd={0, "XXX", 0.0, -1};
	
	if(isExist(VH, ID, A)==TRUE){
		for(;VH.H[A].data.prodID!=ID; A=VH.H[A].next){}
		retProd=VH.H[A].data;
	}
	return retProd;
}

/*If product exists, add to the quantity. If it does not, insert*/
void insertSorted (virtHeap *VH, List *A, prodDet X)
{
	int *trav, ndx;
	
	for(trav=A; *trav!=-1 && VH->H[*trav].data.prodID < X.prodID; trav=&(VH->H[*trav].next)){}
	if (isExist(*VH, X.prodID, *A)==TRUE){
		VH->H[*trav].data.prodQty += X.prodQty;
		VH->H[*trav].data.prodPrice = X.prodPrice;
		strcpy (VH->H[*trav].data.prodDesc, X.prodDesc);
	} else {
		ndx=allocSpace(VH);
		if(ndx > -1){
			VH->H[ndx].data=X;
			VH->H[ndx].next=*trav;
			*trav=ndx;
		}	
	}
}

prodDet deleteFirst (virtHeap *VH, List *A)
{
	prodDet retDel = {0000, "XXX", 0.0, -1};
	List temp;
	
	temp=*A;
	if(*A!=-1){
		retDel=VH->H[*A].data;
		*A=VH->H[*A].next;
		deallocSpace(VH, temp);
	}
	
	return retDel;
}

void deleteProd (virtHeap *VH, List *A, prodDet X)
{
	int temp;
	
	if(isExist(*VH, X.prodID, *A)==FALSE){
		printf("\n Product does not exist");
		printf("\n Press anything to continue...");
		getch();
	} else {
		for(;*A!=-1 && VH->H[*A].data.prodID!=X.prodID;A=&(VH->H[*A].next)){}
		temp=*A;
		if(VH->H[*A].data.prodQty > X.prodQty){
			VH->H[*A].data.prodQty -= X.prodQty;
			VH->H[*A].data.prodPrice = X.prodPrice;
			strcpy (VH->H[*A].data.prodDesc, X.prodDesc);
		} else {
			*A=VH->H[*A].next;
			deallocSpace(VH, temp);
		}
	}
}

void displayAll (virtHeap VH, List A)
{
	printf("\n Contents of Virtual Heap containing products and their respective information");
	printf("\n");
	printf("\n %-15s %-20s %-10s %-12s", "Identifier", "Description", "Price", "Quantity");
	
	for(;A!=-1;A=VH.H[A].next){
		printf("\n");
		printf("%7d", VH.H[A].data.prodID);
		printf("%18s", VH.H[A].data.prodDesc);
		printf("%18.2f", VH.H[A].data.prodPrice);
		printf("%12d", VH.H[A].data.prodQty);
	}
	printf("\nPress anything to continue...");
	getch();	
}

void productDisplay(virtHeap VH, List A, prodDet X)
{
	printf("\n %-15s %-20s %-10s %-12s", "Identifier", "Description", "Price", "Quantity");
	printf("\n%7d", X.prodID);
	printf("%18s", X.prodDesc);
	printf("%18.2f", X.prodPrice);
	printf("%12d", X.prodQty);	
}
