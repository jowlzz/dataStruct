#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define SIZE 10
typedef struct{
	char elem;
	int next;
}Vnode, *vArray;

/*typedef Vnode vArray[SIZE];*/

typedef struct{
	vArray node;
	int avail;
}virtHeap;

typedef struct cell{
	int front;
	int rear;
}Queue;

void initQueueAndList(Queue **Q, virtHeap *V);
void initVHeap(virtHeap *V);
int allocSpace(virtHeap *V);
void deallocSpace(virtHeap *V, int ndx);
void enqueue(virtHeap *V, Queue *Q, char data);
char dequeue(virtHeap *V, Queue *Q);
void display(virtHeap V, Queue Q);

int main ()
{
	virtHeap A;
	Queue *B;
	char data, option, retVal;
	int choice;
	
	initQueueAndList(&B, &A);
	initVHeap(&A);
	
	do{
		printf("\n(1)Enqueue \n(2)Dequeue \n Enter number of chosen action: ");
		scanf("%d", &choice);
		fflush(stdin);
		switch(choice){
			case 1: printf("\n Enter the element you want to enqueue: ");
					scanf("%c", &data);
					fflush(stdin);
					enqueue(&A, B, data);
					break;
			case 2: retVal=dequeue(&A, B);
					printf("\n The element dequeued is %c", retVal);
					break;
			default:printf("\n The option you chose is invalid");
		}
		printf("\n Do you want to continue (Y or N)?");
		scanf("%c", &option);
		fflush(stdin);
	} while(option=='Y'||option=='y');
	
	display(A, *B);
	getch();
	return 0;
}

void initQueueAndList(Queue **Q, virtHeap *V)
{
	(*Q)=(Queue *)malloc(sizeof(struct cell));
	(*Q)->front=-1;
	(*Q)->rear=-1;
	V->node=(vArray)malloc(sizeof(Vnode)*SIZE);
}

void initVHeap(virtHeap *V)
{
	int trav;
	
	for(trav=0;trav<SIZE;trav++){
		V->node[trav].next=trav-1;
	}
	V->avail=SIZE-1;
}
int allocSpace(virtHeap *V)
{
	int ndx;
	
	ndx=V->avail;
	if(ndx!=-1){
		V->avail=V->node[ndx].next;	
	}
	return ndx;
}
void deallocSpace(virtHeap *V, int ndx)
{
	if (ndx>=0&&ndx<SIZE){
		V->node[ndx].next=V->avail;
		V->avail=ndx;
	}
}

void enqueue(virtHeap *V, Queue *Q, char data)
{
	int temp;
	if (V->avail!=-1){
		temp=allocSpace(V);
		V->node[temp].elem=data;
		if(Q->front==-1){
			Q->front=temp;
		} else {
			V->node[Q->rear].next=temp;
		}
		Q->rear=temp;
	}
}
char dequeue(virtHeap *V, Queue *Q)
{
	int temp;
	char retData;
	temp=Q->front;
	if(temp!=-1){
		retData=V->node[temp].elem;
		Q->front=V->node[temp].next;
		deallocSpace(V, temp);
	}
	return retData;
}
void display(virtHeap V, Queue Q)
{
	int trav;
	printf("\n The contents of the virtual heap will be displayed from front to rear.");
	printf("\n The value of the front pointer is %d", Q.front);
	printf("\n The value of the rear pointer is %d", Q.rear);
	for(trav=Q.front;trav!=V.node[Q.rear].next;trav=V.node[trav].next){
		printf("\n Data: %c", V.node[trav].elem);
	}
}
