#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define HEAPSIZE 100

typedef struct{
	int elem;
	int next;
}Heap;

typedef Heap vHeap [HEAPSIZE];

typedef struct{
	vHeap data;
	int avail;
}VH;

typedef enum {TRUE, FALSE}boolean;
typedef int SET;

void initSet (SET *S);
void initHeap (VH *V);
void populateHeap (VH *V, SET *A, SET *B);
void insertElem(VH *V, SET *S, int elem);
int allocSpace (VH *V);
void deallocSpace (VH *V, int node);
void deleteElem (VH *V, SET *S, int elem);
boolean member (VH V, SET S, int elem);
SET UNION (SET A, SET B, VH V);
SET INTERSECTION (SET A, SET B, VH V);
SET DIFFERENCE (SET A, SET B, VH V);
void display (SET S, VH V);

int main ()
{
	SET X, Y, R;
	VH H;
	
	initSet (&X);
	initSet (&Y);
	populateHeap (&H, &X, &Y);
	printf("\n First Set");
	display (X, V);
	printf("\n Second Set");
	display (Y, V);
	R=UNION(X, Y, H);
	printf("\n Union Set");
	display (R, V);
	R=INTERSECTION(X, Y, H);
	printf("\n Intersection Set");
	display (R, V);
	R=DIFFERENCE(X, Y, H);
	printf("\n X-Y Set");
	display (R, V);	
	R=DIFFERENCE(Y, X, H);
	printf("\n Y-X Set");
	display (R, V);	
	
	getch();
	return 0;
}

void initSet (SET *S)
{
	*S=-1;
}

void initHeap (VH *V)
{
	int p;
	
	for(p=0;p<HEAPSIZE;p++){
		V->data[p].next=p-1;
	}
	V->avail=HEAPSIZE-1;
	
}

void populateHeap (VH *V, SET *A, SET *B)
{
	int arrSetA [] ={10, 2, 7, 1, 4};
	int arrSetB []= {6, 8, 5, 2, 10};
	int trav;
	
	for(trav=0;trav<5;trav++){
		insertElem(V, A, arrSetA[trav]);
	}
	
	for(trav=0;trav<5;trav++){
		insertElem(V, B, arrSetB[trav]);
	}	
}

void insertElem(VH *V, SET *S, int elem)
{
	int node;
	
	if(member(*V, *S, elem)!=TRUE){
		if (V->avail!=-1){
			node=allocSpace (V);
			V->data[node].elem=elem;
			V->data[node].next=*S;
			*S=node;
		}
	}	
}

int allocSpace (VH *V)
{
	int ndx;

	ndx=V->avail;
	if(ndx!=-1){
		V->avail=V->data[ndx].next;
	}
	return p;
}

void deallocSpace (VH *V, int node)
{
	if (node!=-1 && node<HEAPSIZE){
		V->data[node].next=V->avail;
		V->avail=node;
	}
}

void deleteElem (VH *V, SET *S, int elem)
{
	SET *trav
	if (member(*V, *S, elem)==TRUE){
		for (trav=S;*trav!=-1 && V->data[*trav].elem!=elem;trav=&(V->data[*trav].next)){}
		if (*trav!=-1){
			deallocSpace(V, *trav)
		}
	}
}

boolean member (VH V, SET S, int elem)
{
	for (;S!=-1 && V.data[S].elem!=elem;S=V.data[S].next){}
	return (S==-1?FALSE:TRUE);
}

SET UNION (SET A, SET B, VH V)
{
	SET *R;
	if (V->avail!=-1){
		if (A==-1 && B!=-1){
			memcpy (&(V->data[]))
		}
	}
}
SET INTERSECTION (SET A, SET B, VH V);
SET DIFFERENCE (SET A, SET B, VH V);
void display (SET S, VH V);
