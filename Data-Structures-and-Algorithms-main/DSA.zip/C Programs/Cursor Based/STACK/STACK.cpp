#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define SIZE 10

typedef struct{
   char elem;
   int next;	
}nodeType;

typedef nodeType vArray[SIZE];

typedef struct{
	vArray node;
	int avail;
}virtualHeap;

typedef int top;

void initList(top *L);
void initVHeap(virtualHeap *V);
int allocSpace(virtualHeap *V);
void deallocSpace(virtualHeap *V, int ndx);
void push(virtualHeap *V, top *L, char data);
char pop(virtualHeap *V, top *L);
void display(virtualHeap V, top L);

int main ()
{
	virtualHeap V;
	top head;
	char data, option, retVal;
	int choice;
	
	initList(&head);
	initVHeap(&V);
	
	do{
		printf("\n(1)Push \n(2)Pop \n Enter number of chosen action: ");
		scanf("%d",&choice);
		fflush(stdin);
		switch(choice){
			case 1: printf("\n Enter the element you want to push: ");
					scanf("%c",&data);
					fflush(stdin);
					push(&V, &head, data);
					break;
			case 2: retVal=pop(&V, &head);
					printf("\n The element you just popped is %c", retVal);
					break;
			default: printf("\n The option you entered was invalid.");
		}
		printf("\n Do you want to continue(Y or N)?");
		scanf("%c",&option);
		fflush(stdin);
	} while(option=='Y'||option=='y');
	
	display(V, head);
	getch();
	return 0;
}

void initList(top *L)
{
	(*L)=-1;
}
void initVHeap(virtualHeap *V)
{
	int trav;
	
	for(trav=0;trav<SIZE;trav++){
		V->node[trav].next=trav-1;
	}
	V->avail=SIZE-1;
}
int allocSpace(virtualHeap *V)
{
	int retVal;
	retVal=V->avail;
	if(retVal!=-1){
		V->avail=V->node[retVal].next;
	}
	return retVal;
}
void deallocSpace(virtualHeap *V, int ndx)
{
	if(ndx>=0 && ndx<SIZE){
		V->node[ndx].next=V->avail;
		V->avail=ndx;
	}
}
void push(virtualHeap *V, top *L, char data)
{
	int ndx;
	top *p;
	p=L;
	if(V->avail!=-1){
		ndx=allocSpace(V);
		if(ndx!=-1){
			V->node[ndx].elem=data;
			V->node[ndx].next=*p;
			*p=ndx;
		}
	}
}
char pop(virtualHeap *V, top *L)
{
	int temp;
	char retData;
	
	retData=0;
	temp=*L;
	if (temp!=-1){
		retData=V->node[*L].elem;
		*L=V->node[temp].next;
		deallocSpace(V, temp);
	}
	return retData;
}
void display(virtualHeap V, top L)
{
	printf("\n The data in the virtual Heap");
	for(;L!=-1;L=V.node[L].next){
	
		printf("\n Data: %c", V.node[L].elem);
	}
}
