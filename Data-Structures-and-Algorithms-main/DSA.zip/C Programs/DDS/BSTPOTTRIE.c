/****************************************************************************
 * Program Description: This program will contain a record of products. 	* 
 * The students will then be ordered using a binary tree based on their		*
 * price, using a heap based on their prodcut ID. A trie will also be used	*
 * to store their product name.												*
 * Programmer: Ventura, Jane Colleen T.										*
 * Date Created : 3/12/16													*
****************************************************************************/

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define HEAPSIZE 30

typedef enum {TRUE, FALSE}boolean;

typedef struct {
    unsigned int prodID; /* product ID*/
 	char prodName[15]; /* product description*/
 	float prodPrice; /* product price*/
 	int prodQty; /* product count or quantity */
}product; /* product record */

typedef struct{
	product item;
	int LC;
	int RC;
}nodeType;

typedef nodeType bstNode [HEAPSIZE];

typedef struct {
	bstNode node;
	int avail;
}virtualHeap;

typedef int BST;

typedef struct{
	unsigned int Heap[HEAPSIZE];
	int last;
}POT;

typedef struct cell {
	char letter;
	struct cell *nextSib;
	struct cell *nextLet;
}*TRIE;

void populate (TRIE *X, BST *B, virtualHeap *V, POT *A);

/*Functions for BST*/
void initializeVHeap (virtualHeap *V);
void initializeBST (BST *B);
int allocSpace (virtualHeap *V);
void deallocSpace (virtualHeap *V, int ndx);
void insertBST (BST *B, virtualHeap *V, product elem);
product deleteBST (virtualHeap *V, BST *B, unsigned int ID);
boolean isElem (virtualHeap V, BST B, unsigned int ID);
product deleteMin (virtualHeap *V, BST *B);

/*Functions for POT*/
void initializePOT (POT *A);
void heapify (POT *A);
void insertHeap (POT *A, unsigned int ID);
product deleteMinPOT (POT *A, virtualHeap *V, BST *B);

/*Functions for Trie*/
void initializeTrie (TRIE *X);
void insertName (TRIE *X, char *name);
char * deleteName (TRIE *X, char *name);
boolean nameExist (TRIE X, char *name);

/*Display Functions*/
/*void displayAllBrands (TRIE X);*/
void SortedDisplay (BST B, virtualHeap V);
void displayVHeap(virtualHeap V);
void displayRec (product D);
void displayPOT(POT A);

int main ()
{
	char choice;
	virtualHeap V;
	BST B;
	POT A;
	TRIE X;
	unsigned int existID = 1601;
	unsigned int notID = 1598;
	unsigned int firstID = 1501;
	char existName [] = "Ferrero";
	char notName [] = "Cloud9";
	
	initializeVHeap(&V);
	initializeBST(&B);
	initializePOT(&A);
	initializeTrie(&X);
	
	populate(&X, &B, &V, &A);
	heapify (&A);
	
	displayVHeap(V);
	displayPOT(A);
	printf ("\n %10s %15s %10s %10s", "Product ID", "Product Name", "Price", "Quantity");
	SortedDisplay (B, V);
	/*displayAllBrands(X);*/
	
	do{
		printf("\n Deleted Product: ");
		printf ("\n %10s %15s %10s %10s", "Product ID", "Product Name", "Price", "Quantity");
		displayRec(deleteMinPOT(&A, &V, &B));
		printf("\n Do you want to continue to serve the candy? ");
		scanf("%c",&choice);
		fflush(stdin);
	} while (choice=='Y'||choice=='y');
	
	displayVHeap(V);
	displayPOT(A);
	printf ("\n %10s %15s %10s %10s", "Product ID", "Product Name", "Price", "Quantity");
	SortedDisplay (B, V);
	
	/*printf("\n This name is now deleted: ");
	printf("\n The name %s has now been deleted",deleteName(&X, existName));
	printf("\n The name %s has now been deleted",deleteName(&X, notName))
	
	
	printf("\nAfter all functions : ");
	SortedDisplay (A, B, V);
	displayAllBrands(X);*/
	
	getch();
	return 0;
}
/*Functions for BST*/
void initializeVHeap (virtualHeap *V)
{
	int p;
	
	for(p=HEAPSIZE-1;p>-1;p--){
		V->node[p].LC=p+1;
		V->node[p].RC=1000;
		V->node[p].item.prodID=0;
	}
	V->avail=0;
}

void initializeBST (BST *B)
{
	*B=-1;
}

int allocSpace (virtualHeap *V)
{
	int ndx;
	ndx=V->avail;
	V->avail=V->node[V->avail].LC;
	return ndx;
}

void deallocSpace (virtualHeap *V, int ndx)
{
	if (ndx>-1){
		V->node[ndx].item.prodID=0;
		V->node[ndx].LC=V->avail;
		V->node[ndx].RC=1000;
		V->avail=ndx;
	}
}

void insertBST (BST *B, virtualHeap *V, product elem)
{
	int ndx;
	BST *trav;
	if (V->avail>-1){
		trav=B;
		while(V->node[*trav].item.prodID!=0 && *trav>-1 && *trav<HEAPSIZE && V->node[*trav].item.prodID!=elem.prodID){
			if(V->node[*trav].item.prodID<elem.prodID){
				trav=&V->node[*trav].RC;
			} else {
				trav=&V->node[*trav].LC;
			}
		}
		
		if (isElem (*V, *B, elem.prodID)==FALSE){
			ndx=allocSpace(V);
			V->node[ndx].RC=V->node[ndx].LC=-1;
			if(*trav>-1 && V->node[*trav].item.prodID>elem.prodID){
				V->node[ndx].RC=*trav;
			} else if (*trav>-1 && V->node[*trav].item.prodID<elem.prodID){
				V->node[ndx].LC=*trav;
			}
			V->node[ndx].item=elem;
			*trav=ndx;
		} 
	}
}

void populate (TRIE *X, BST *B, virtualHeap *V, POT *A)
{
	int x;
	product data[] = { {1501, "Hersheys", 100.50, 10},
					   {1701, "Toblerone", 150.75, 20},
				   	   {1550, "Kitkat", 200.00, 30},
				   	   {1201, "Toffee", 97.75, 40},
				   	   {1450, "Ferrero", 150.50, 50},
				   	   {1601, "Cadburry", 75.50, 60},
				   	   {1301, "Nestle", 124.50, 70},
				   	   {1525, "Lindt", 175.50, 80},
				   	   {1545, "Valor", 100.50, 90},
				   	   {1455, "Tango", 49.50, 100}
 				 	 };
    for(x = 0; x < 10; x++){
 	    insertBST(B, V, data[x]);
 	    insertHeap(A, data[x].prodID);
 	    insertName(X, data[x].prodName);
	}
}

product deleteBST (virtualHeap *V, BST *B, unsigned int ID)
{
	int ndx;
	BST *trav;
	product ret;
	trav=B;
	
	while(V->node[*trav].item.prodID!=0 && *trav>-1 && *trav < HEAPSIZE && V->node[*trav].item.prodID!=ID){
		if(V->node[*trav].item.prodID<ID){
			trav=&V->node[*trav].RC;
		} else {
			trav=&V->node[*trav].LC;
		}
	}
	
	if (*trav>-1 && *trav < HEAPSIZE && V->node[*trav].item.prodID==ID){
		
		ret=V->node[*trav].item;
		if(V->node[*trav].LC>-1 && V->node[*trav].LC<HEAPSIZE && V->node[*trav].RC>-1 && V->node[*trav].RC<HEAPSIZE){
			V->node[*trav].item=deleteMin(V, B);
		} else {
			ndx=*trav;
			if(V->node[*trav].LC>-1 && V->node[*trav].LC<HEAPSIZE){
				*trav=V->node[*trav].LC;
			} else {
				*trav=V->node[*trav].RC;
			}
			deallocSpace (V, ndx);
		}
	}	
	return ret;
}

boolean isElem (virtualHeap V, BST B, unsigned int ID)
{
	while (B>-1 && B<HEAPSIZE && V.node[B].item.prodID!=ID){
		if (V.node[B].item.prodID>ID){
			B=V.node[B].LC;
		} else {
			B=V.node[B].RC;
		}
	}
	return ((B>-1 && B<HEAPSIZE)?TRUE:FALSE);
}

product deleteMin (virtualHeap *V, BST *B)
{
	BST *trav, temp;
	product data;
	
	for(trav=B; *trav>-1 && *trav<HEAPSIZE && V->node[*trav].item.prodID!=0; *trav=V->node[*trav].LC){}
	
	data=V->node[*trav].item;
	temp=*trav;
	deallocSpace(V, temp);
	
	return data;
}

/*Functions for POT*/
void initializePOT (POT *A)
{
	(*A).last=-1;
}

void heapify (POT *A)
{
	int par, child, trav, temp;
	
	for(trav=(*A).last;trav>-1;trav--){
		par=trav;
		child=(par*2)+1;
		while (child<=(*A).last && (*A).Heap[child]<(*A).Heap[par] || child+1<=(*A).last && (*A).Heap[child+1]<(*A).Heap[par]){
			if (child+1<=(*A).last && (*A).Heap[child+1]<(*A).Heap[child]){
				child++;
			}
			temp=(*A).Heap[par];
			(*A).Heap[par]=(*A).Heap[child];
			(*A).Heap[child]=temp;
			
			par=child;
			child=2*child-1;
		} 
	}
}

void insertHeap (POT *A, unsigned int ID)
{
	(*A).last++;
	(*A).Heap[(*A).last]=ID;
}

product deleteMinPOT (POT *A, virtualHeap *V, BST *B)
{
	int minID, par, child, flag, temp;
	BST *trav;
	product ret;
	
	minID=(*A).Heap[0];
	(*A).Heap[0]=(*A).Heap[(*A).last];
	(*A).last--;
	
	flag=par=0;
	child=2*par+1;
	
	while (child<=(*A).last&&flag==0){
		if(child+1<=(*A).last && (*A).Heap[child]>(*A).Heap[child+1]){
			child++;
		}		
		if((*A).Heap[child]<(*A).Heap[par]){
			temp=(*A).Heap[par];
			(*A).Heap[par]=(*A).Heap[child];
			(*A).Heap[child]=temp;
			
			par=child;
			child=2*child+1;
		} else {
			flag=1;
		}
	}
	
	ret=deleteBST(V, B, minID);
	return ret;
}

/*Functions for Trie*/
void initializeTrie (TRIE *X)
{ 
	*X=NULL;
}

void insertName (TRIE *X, char *name)
{
	TRIE *trav, temp;
	int i;
	
	for(trav=X, i=0; *trav!=NULL && name[i]!=(*trav)->letter; trav=&(*trav)->nextSib){}
	while(*trav!=NULL && i<=strlen(name) && (*trav)->letter!='[' && (*trav)->letter==name[i]){
		i++;
		trav=&(*trav)->nextLet;
	}
	
	while (*trav!=NULL){
		trav=&(*trav)->nextSib;
	}
	
	if(i<=strlen(name)){
		while(i<=strlen(name)){
			temp=(TRIE)malloc(sizeof(struct cell));
			if(temp!=NULL){
				temp->letter=name[i];
				temp->nextSib=temp->nextLet=NULL;
				*trav=temp;
			}
		trav=&(*trav)->nextLet;
		i++;
		}
		temp=(TRIE)malloc(sizeof(struct cell));
		if(temp!=NULL){
			temp->letter='[';
			temp->nextSib=NULL;
			*trav=temp;
		}
	}
}
/*char * deleteName (TRIE *X, char *name)
{
	TRIE *trav, temp, tempA;	
	int p;
	
	for(trav=X, p=0;*trav!=NULL && (*trav)->letter!=name[p];trav=&(*trav)->nextSib){}
	if (*trav!=NULL){
		temp=*trav;
	}
	while((*trav)!=NULL && (*trav)->letter!='['&& p<=strlen(name) && (*trav)->letter==name[p]){
		p++;
		trav=&(*trav)->nextLet;
	}
	
	if(p<strlen(name)){
		while(*trav!=NULL && (*trav)->letter!=name[p]){
			trav=&(*trav)->nextSib;
		}
		if ((*trav)!=NULL){
			temp=*trav;
			while(*trav!=NULL && p<=strlen(name) && (*trav)->letter!='[' && (*trav)->letter==name[p]){
				trav=&(*)
			}
		}
	}
}*/
boolean nameExist (TRIE X, char *name)
{
	int trav, flag=0;
	
	for(trav=flag=0;X!=NULL && X->letter!=name[trav];X=X->nextSib){}
	
	while(X!=NULL && flag=0){
	 	if (X->letter==name[trav]){
			trav++;
			X=X->nextLet;
		} else {
			flag=1;
		}
	}
	return flag;
}

/*Display Functions*/
void displayVHeap(virtualHeap V)
{
    int ndx;
    system("cls");
	printf("\nContents of the Virtual Heap");
	printf("\n\nAvail : %d", V.avail);
	printf("\n%5s%15s%10s%10s","Index","Product ID","LC","RC");
	for(ndx = 0; ndx < HEAPSIZE; ndx++){
		printf("\n%5d", ndx);
		printf("%15d", V.node[ndx].item.prodID);
		printf("%10d", V.node[ndx].LC);
		printf("%10d", V.node[ndx].RC);
	}
 	printf("\n\nPress any key to continue... ");
 	getch();
} 

void displayAllBrands (TRIE X)
{
	char brand[50];
		
}
void SortedDisplay (BST B, virtualHeap V)
{
	int trav, temp;
	trav=0;
	if (B!=-1){
		SortedDisplay(V.node[B].LC, V);
		displayRec(V.node[B].item);
		SortedDisplay(V.node[B].RC, V);
	}
}

void displayRec (product data)
{
	printf("\n");
	printf("  %-15d", data.prodID);
	printf("%-15s", data.prodName);
	printf("%-13.2f", data.prodPrice);
	printf("%-10d", data.prodQty);
}

void displayPOT (POT A)
{
	int trav;
	
	system("cls");
	printf("\n ID numbers stored based on priority: ");
	printf("\n");
	for(trav=0;trav<=A.last;trav++){
		printf("%-10d", A.Heap[trav]);
	}
	printf("\n\nPress any key to continue... ");
 	getch();
}

