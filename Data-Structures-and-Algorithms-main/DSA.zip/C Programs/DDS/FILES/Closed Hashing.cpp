#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 20

typedef struct {
   char LN[16], MI, FN[24];        /* Lastname, Middle initial, firstname    */
}nameType;
typedef struct {
   char ID[11];                    /* Uniquely identifies the student record */
   nameType name;                  /* complete name                          */
   float grade126;                 /* Grade in CS/IT 126                     */  
}studType;	

#define SIZE sizeof(studType)+4

typedef  struct cell {
   studType data;
   int rank;
} list;

typedef struct dualNode {
   list hTable[MAX];      /* Each list in the hash table is sorted in ascending order according to ID */
   int rankLadder[MAX];  /* Each ndx is a pointer to the node                                        */
}*DDS;                            /* Definition of the dual data structure */


/******************************************************************
 * Function Prototypes                                            *
 ******************************************************************/
void initializeDDS(DDS *D);                    
void displayDDS(DDS D);                        
int hashFunction(char *ID);                   
void populateFile();
void populateDDS(DDS D);                           
list challenge(DDS D, char *ID);       
void displayStudent(list N);         
void changeGrade(DDS D, char *ID, float newGrade);  
void write (studType data, FILE *ptr);

int main ()
{
	DDS A;
	char foundID[11] = "13103998";     //Tan
	char foundOne[11] = "13100542";  //Gabon
	char notFound[11] = "12104593";   //not in the DDS
	 
	initializeDDS(&A);
	populateFile();
	displayDDS(A);
	populateDDS(A);
	displayDDS(A);
	displayStudent(challenge(A, foundID));
	changeGrade(A, foundID, 1.3);
	displayDDS(A);
	
	getch();
	return 0;
}
 
void initializeDDS(DDS *D)
{
	int trav;

	*D=(DDS)malloc(sizeof(struct dualNode));
	printf("P");
	for(trav=0;trav<MAX;trav++){
		(*D)->hTable[trav].rank=-1;
	}	
	(*D)->rankLadder[0]=0;
}                    
                        
int hashFunction(char *ID)
{
	int trav, num;
	
	
	for(trav=0;trav<11;trav++){
		num+=(trav%2==0?ID[trav]*100:ID[trav]);
	}
	
	return num%MAX;
}                   
                           
list challenge(DDS D, char *ID)
{
	int hashVal, rank;
	list challenger;
	list retVal= {{ "XXXX",  {"XXXX", '0', "XXXX"}   , 0.0}, 0};
	list retVal2={{ "YYYY",  {"YYYY", '0', "YYYY"}   , 0.0}, 0};
	
	hashVal=hashFunction(ID);
	if(strcmp(D->hTable[hashVal].data.ID, ID)!=0){
		challenger=retVal;
	} else if (D->hTable[hashVal].rank==1){
		challenger=retVal2;
	} else {
		rank=D->hTable[hashVal].rank;
		rank=D->rankLadder[rank-1];
	}
	
	return challenger;
}       

void displayStudent(list N)
{
	printf("\n %-10s %-15s %-20s %-5s", "Rank", "ID No.", "Name", "Grade");
	printf("\n");
	printf(" %-10d", N.rank);
	printf("%-15s", N.data.ID);
	printf("%s, %s %-10c", N.data.name.LN, N.data.name.FN, N.data.name.MI);
	printf("%.2f", N.data.grade126);
		
	printf("\n\nPress any key to continue...");
	getch();
}    
   
void changeGrade(DDS D, char *ID, float newGrade)
{
	int hashVal, trav, oldRank, move;
	
	hashVal=hashFunction(ID);
	if (strcmp(D->hTable[hashVal].data.ID,ID)!=0){
		printf("\n Student does not exist");
	} else {
		oldRank=D->hTable[hashVal].rank;
		for (trav=1;trav<MAX && D->hTable[D->rankLadder[trav]].data.grade126 > newGrade;trav++){}
		D->hTable[hashVal].data.grade126=newGrade;
		if (oldRank>trav){
			for(move=oldRank;move!=trav;move--){
				D->rankLadder[move]=D->rankLadder[move-1];
				D->hTable[D->rankLadder[move]].rank=move;
			}
		} else if (oldRank<trav){
			for(move=oldRank;move!=trav;move++){
				D->rankLadder[move]=D->rankLadder[move+1];
				D->hTable[D->rankLadder[move]].rank=move;
		
			}
		}
			D->rankLadder[trav]=hashVal;
			D->hTable[D->rankLadder[trav]].rank=trav;
			
	}
} 
void populateDDS(DDS D)
{
	FILE *ptr;
	int trav, cnt, i, hashVal;
	studType temp;
	
	ptr=fopen("Records.dat", "rb");
	for (trav=0; trav<MAX && fread(&temp, sizeof(studType), 1, ptr)!=0; trav++){
		hashVal=hashFunction(temp.ID);
		D->hTable[hashVal].data=temp;
		D->rankLadder[0]++;
		for(cnt=1;cnt<D->rankLadder[0] && D->rankLadder[0]<MAX && D->hTable[D->rankLadder[cnt]].data.grade126 < temp.grade126;cnt++){}
		for(i=D->rankLadder[0];i>cnt;i--){
			D->rankLadder[i]=D->rankLadder[i-1];
			D->hTable[D->rankLadder[i]].rank=i;
		}
		D->rankLadder[cnt]=hashVal;
		D->hTable[hashVal].rank=cnt;
	}
	fclose(ptr);
}
/*void write (studType data, FILE *fptr)
{
	if(fptr!=NULL){
		fwrite(&data, sizeof(studType), 1 , fptr);
	}	
} */

void populateFile()
{
	int x;
	FILE *ptr;
	studType data[] = { { "13103701",  {"ABANGAN", 'A', "BEN"}   , 2.3},
					    { "13104175",  {"SALINAS", 'B', "HERZON"}, 2.5},
					    { "13101596",  {"CACANOG", 'C', "CHRISTEN"}, 1.9},
				        { "13100542",  {"GABON", 'D', "JARELL"}, 1.5},
						{ "12104363",  {"APOR", 'E', "JOHN"}, 1.5},
						{ "13104474",  {"CANALES", 'F', "JOVER"}, 1.7},
						{ "12105298",  {"TANTAY", 'G', "AXEL"}, 2.0},
						{ "13103473",  {"YAP", 'H', "MARK"}, 2.1},
						{"13101596",  {"CACANOG", 'C', "CHRISTEN"}, 1.9},
						{ "13104172	",  {"CALZADA", 'I', "KARL"}, 1.8},
						{ "13103998",  {"TAN", 'J', "CRIS"}, 2.4}
		              };
   
   	ptr=fopen("Records.dat", "wb");
   	for(x = 0; x < 11; x++){
		fwrite(&data[x], sizeof(studType), 1 , ptr);
	}		          
	fclose(ptr);
}

void displayDDS(DDS D)
{
	int ndx;
	
	system("cls");
	printf("\n %-10s %-15s %-20s %-5s", "Rank", "ID No.", "Name", "Grade");
	for(ndx=1;ndx<=D->rankLadder[0];ndx++){
		printf("\n");
		printf(" %-10d", D->hTable[D->rankLadder[ndx]].rank);
		printf("%-15s", D->hTable[D->rankLadder[ndx]].data.ID);
		printf("%s, %s %-10c", D->hTable[D->rankLadder[ndx]].data.name.LN, D->hTable[D->rankLadder[ndx]].data.name.FN, D->hTable[D->rankLadder[ndx]].data.name.MI);
		printf("%.2f", D->hTable[D->rankLadder[ndx]].data.grade126);
	}
	printf("\n\nPress any key to continue...");
	getch();
}

 /*void displayDDS(DDS D)
{
	int ndx;
	list ptr;
	char temp[24];
	
	system("cls");
	printf("\nContents of the Dual Data Structure\n");
	printf("\n%-8s%-50s%","Index","Elements of Hash Table");
	printf("\n%-8s%-50s%","-----","----------------------");
	for(ndx = 0; ndx <  MAX; ndx++){
		printf("\n%-8d", ndx);
	   	sprintf(temp,"%s [#%d - %2.1f]",D->hTable[ndx].data.name.LN, D->hTable[ndx].rank, D->hTable[ndx].data.grade126);
	   	   printf("%-25s", temp);
	}
	printf("\n\nRankLadder Entry: [lastNdx = %d]", D->rankLadder[0] );
	printf("\n-----------------");
	for(ndx = 1; ndx <= D->rankLadder[0]; ndx++){
		printf("\n[%2d] : ", ndx);
	    printf("%-10d ", D->rankLadder[ndx] );
	    
    } 
    
    printf("\n\nPress any key to continue...");
    getch();
 }
 
*/
