/******************************************************************
 * Project Name:  Dual Data Structure Application                 *
 * Programmer  :  Put your Name here                              *
 * Date Completed: August 17, 2015                                 *
 ******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/******************************************************************
 * Data Structure Definition                                      *
 ******************************************************************/
#define HTABLE_SIZE  10
#define LADDER_SIZE  51            /* Reduce to 11 to 15 during testing      */

typedef struct {
   char LN[16], MI, FN[24];        /* Lastname, Middle initial, firstname    */
}nameType;
typedef struct {
   char ID[11];                    /* Uniquely identifies the student record */
   nameType name;                  /* complete name                          */
   float grade126;                 /* Grade in CS/IT 126                     */  
}studType;	

typedef struct {
   studType stud;
   int rank;                     /* rank of student in the DDS, highest rank is 1 */ 
}nodeType;

typedef  struct cell {
   nodeType data;
   struct cell *next;
} *list;

typedef struct dualNode {
   list hTable[HTABLE_SIZE];      /* Each list in the hash table is sorted in ascending order according to ID */
   list rankLadder[LADDER_SIZE];  /* Each ndx is a pointer to the node                                        */
   int lastNdx;                   /* holds the index of the last entry in the rankLadder; NOTE: index 0 is NOT a valid index in the rankladder */
}*DDS;                            /* Definition of the dual data structure */



/******************************************************************
 * Function Prototypes                                            *
 ******************************************************************/
void initializeDDS(DDS *D);                    
void displayDDS(DDS D);                        
int hashFunction(char *ID);                   
void populateDDS(DDS D);                  
void insertDDS(DDS D, studType S);          
nodeType challenge(DDS D, char *ID);       
void displayStudent(nodeType N);         
void changeGrade(DDS D, char *ID, float newGrade);  


int main(void) 
{
	DDS A;
	char foundID[11] = "13103998";     //Tan
	char foundOne[11] = "13100542";  //Gabon
	char notFound[11] = "12104593";   //not in the DDS
	 
	 initializeDDS(&A);
/*------------------------------------------------------------------------------------------------
 * To facilitate the checking of the program, the following functions should be called or invoked  
 * You may add other function calls necessary to make the listed function calls work. 
 * SEPARATE the group of function calls representing each number below  with 1 LINE
 *                   
 *    1]  Call displayDDS() 
 *        */displayDDS(A);/*
 *    2]  Call populateDDS()                                    
 *        Call displayDDS()  
 		  */populateDDS(A);                                                                      
 		   displayDDS(A);/*
 * 	  3] Call challenge() and display the returned student record     
 *		  */displayStudent(challenge(A, foundID));/*
 * 	  4] Call changeGrade() and call displayDDS()                                                           
 *         */changeGrade(A, foundID, 1.8);
 			  displayDDS(A);/*
 *-------------------------------------------------------------------------------------------------*/  

	

	printf("\n\nPress any key to continue...");
	getch();
	return 0;
}

void initializeDDS(DDS *D)
{
	int trav;
	*D=(DDS)malloc(sizeof(struct dualNode));
	for (trav=0;trav<HTABLE_SIZE;trav++){
		(*D)->hTable[trav]=NULL;
		(*D)->rankLadder[trav]=NULL;
	}
	for(;trav<LADDER_SIZE;trav++){
		(*D)->rankLadder[trav]=NULL;
	}
	(*D)->lastNdx=0;
}      
                                     
int hashFunction(char *ID)
{
	int cnt, num;
	num=0;
	for(cnt=0;cnt<11;cnt++){
		num+=(cnt%2==0?ID[cnt]*100:ID[cnt]);
	}
	return num%HTABLE_SIZE;
}                                
void insertDDS(DDS D, studType S)
{
	int hashVal, comp, i;
	list *trav, temp;
	
	hashVal=hashFunction(S.ID);
	for(trav=&D->hTable[hashVal];*trav!=NULL && strcmp((*trav)->data.stud.ID, S.ID)<0;trav=&(*trav)->next){}
	if(*trav==NULL || strcmp((*trav)->data.stud.ID, S.ID)!=0){
		temp=(list)malloc(sizeof(struct cell));
		if(temp!=NULL){
			temp->data.stud=S;
			temp->next=*trav;
			*trav=temp;
		}
		D->lastNdx++;
		for(comp=1;comp<D->lastNdx && S.grade126>D->rankLadder[comp]->data.stud.grade126;comp++){}
		for(i=D->lastNdx;i>comp;i--){
			D->rankLadder[i]=D->rankLadder[i-1];
			D->rankLadder[i]->data.rank=i;
		}
		D->rankLadder[comp]=*trav;
		D->rankLadder[comp]->data.rank=comp;
	}
}  

nodeType challenge(DDS D, char *ID)
{
	nodeType retVal= {{ "XXXX",  {"XXXX", '0', "XXXX"}   , 0.0}, 0};
	nodeType retVal2={{ "YYYY",  {"YYYY", '0', "YYYY"}   , 0.0}, 0};
	int trav, p;
	list find;
	
	p=hashFunction(ID);
	for(find=D->hTable[p];find!=NULL && strcmp(ID, find->data.stud.ID)!=0;find=find->next){}
	if(find!=NULL){
		if(find->data.rank==1){
			retVal=retVal2;
		}else {
			retVal=D->rankLadder[find->data.rank-1]->data;
		}
	}
	return retVal;
	
}      
void displayStudent(nodeType N)
{
	printf("\n %-10s %-15s %-20s %-5s", "Rank", "ID No.", "Name", "Grade");
	printf("\n");
	printf(" %-10d", N.rank);
	printf("%-15s", N.stud.ID);
	printf("%s, %s %-10c", N.stud.name.LN, N.stud.name.FN, N.stud.name.MI);
	printf("%.2f", N.stud.grade126);
		
	printf("\n\nPress any key to continue...");
	getch();
}         
void changeGrade(DDS D, char *ID, float newGrade)
{
	int trav, hashVal, val1;
	list temp;
	
	hashVal=hashFunction(ID);
	for(temp=D->hTable[hashVal];strcmp(temp->data.stud.ID, ID)!=0;temp=temp->next);
	
	val1=temp->data.rank;
	for(trav=1;trav<D->lastNdx && newGrade > D->rankLadder[trav]->data.stud.grade126;trav++){}
	temp->data.stud.grade126=newGrade;
	
	if(val1>trav){
		for(;val1>trav;val1--){
			D->rankLadder[val1]=D->rankLadder[val1-1];
			D->rankLadder[val1]->data.rank=val1;		
		}
	} else if (val1<trav){
		for(;val1<trav;val1++){
			D->rankLadder[val1]=D->rankLadder[val1+1];
			D->rankLadder[val1]->data.rank=val1;
		}
	}
	D->rankLadder[trav]=temp;
	D->rankLadder[trav]->data.rank=trav;
} 
 
/***********************************************************************
 * Populates the DDS with 10 student records  by calling          *
 * insertDDS() function.                                  *
 ************************************************************************/
void populateDDS(DDS D)
{
	int x;
	studType data[] = { { "13103701",  {"ABANGAN", 'A', "BEN"}   , 2.3},
					    { "13104175",  {"SALINAS", 'B', "HERZON"}, 2.5},
					    { "13101596",  {"CACANOG", 'C', "CHRISTEN"}, 1.9},
				        { "13100542",  {"GABON", 'D', "JARELL"}, 1.5},
						{ "12104363",  {"APOR", 'E', "JOHN"}, 1.5},
						{ "13104474",  {"CANALES", 'F', "JOVER"}, 1.7},
						{ "12105298",  {"TANTAY", 'G', "AXEL"}, 2.0},
						{ "13103473",  {"YAP", 'H', "MARK"}, 2.1},
						{"13101596",  {"CACANOG", 'C', "CHRISTEN"}, 1.9},
						{ "13104172	",  {"CALZADA", 'I', "KARL"}, 1.8},
						{ "13103998",  {"TAN", 'J', "CRIS"}, 2.4}
		              };
   
   	for(x = 0; x < 11; x++){
		insertDDS(D,data[x]);
	}		          
}

/* ***********************************************************************
 * The function displays entries of the hash table, rankladder  *
*   and lastNdx variable. For each student record, the name,    *
*   his/her rank and CS/IT 126 grade will be displayed. *
 ************************************************************************/
 void displayDDS(DDS D)
{
	int ndx;
	list ptr;
	char temp[24];
	
	system("cls");
	printf("\nContents of the Dual Data Structure\n");
	printf("\n%-8s%-50s%","Index","Elements of Hash Table");
	printf("\n%-8s%-50s%","-----","----------------------");
	for(ndx = 0; ndx <  HTABLE_SIZE; ndx++){
		printf("\n%-8d", ndx);
	   for(ptr = D->hTable[ndx]; ptr != NULL; ptr = ptr->next){
	   	   sprintf(temp,"%s [#%d - %2.1f]",ptr->data.stud.name.LN, ptr->data.rank, ptr->data.stud.grade126);
	   	   printf("%-25s", temp);
	   }
	}
	printf("\n\nRankLadder Entry: [lastNdx = %d]", D->lastNdx );
	printf("\n-----------------");
	for(ndx = 1; ndx <= D->lastNdx; ndx++){
		printf("\n[%2d] : ", ndx);
	    printf("%-10s ", D->rankLadder[ndx]->data.stud.name.LN );
	    printf("[%2.1f]", D->rankLadder[ndx]->data.stud.grade126);
	    
    } 
    
    printf("\n\nPress any key to continue...");
    getch();
 }



