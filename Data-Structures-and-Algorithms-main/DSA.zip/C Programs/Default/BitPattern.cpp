#include<stdio.h>
#include<conio.h>

void dispBitPattern(int num);

int main ()
{
	int chosenNum;
	
	printf("\n Enter a number: ");
	scanf("%d", &chosenNum);
	dispBitPattern(chosenNum);
	getch();
	return 0;
}

void dispBitPattern(int num)
{
    unsigned mask;
    int trav, bits;
    bits = (sizeof(int) * 8);
    mask = 1 << (bits - 1);
    for (trav = 1; trav <= bits; trav++){
	    (num & mask) ? printf ("1"): printf ("0");
	    if(trav % 4 ==0){
	    	printf(" ");
		}
         mask >>= 1;
     }
}
