#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

float addition(float val1, float val2);
float subtraction(float val1, float val2);
float multiplication(float val1, float val2);
float division(float val1, float val2);
void displayAns(float ans);

int main()
{
	float num1, num2;
	int option;
	char choice;
	
	printf("\n Enter first number: ");
	scanf("%f", &num1);
	fflush(stdin);
	
	do{
		printf("\n Enter second number: ");
		scanf("%f", &num2);
		printf("\n(1)Addition \n(2)Subtraction \n(3)Multiplication \n(4)Division \n(Any other number) Display \n Choose an option: ");
		scanf("%d", &option);
		fflush(stdin);
		switch(option){
			case 1: num1=addition(num1, num2);
					break;
			case 2: num1=subtraction(num1, num2);
					break;
			case 3: num1=multiplication(num1, num2);
					break;
			case 4: num1=division(num1, num2);
					break;
			default:displayAns(num1);
					break;	
		}
		printf("\n Do you want to continue (Y or N)?");
		scanf("%c", &choice);
		fflush(stdin);
	} while(choice=='y'||choice=='Y');
}

float addition(float val1, float val2)
{
	float sum;
	
	sum = val1 + val2;
	return sum;
}

float subtraction(float val1, float val2)
{
	float diff;
	diff = val1-val2;
	return diff;
}

float multiplication(float val1, float val2)
{
	float product;
	product = val1 * val2;
	
	return product;
}

float division(float val1, float val2)
{
	float quotient;
	
	quotient = val1/val2;
	return quotient;
}

void displayAns(float ans)
{
	printf("\n The answer is: %.2f", ans);
}


