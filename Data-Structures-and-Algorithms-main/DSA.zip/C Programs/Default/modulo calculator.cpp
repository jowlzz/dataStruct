#include<stdio.h>
#include<conio.h>

int main()
{
	int num1, num2, result;
	char choice;
	
	do{
		printf("\n Enter first number: ");
		scanf("%d", &num1);
		fflush(stdin);
		printf("\n Enter second number: ");
		scanf("%d", &num2);
		fflush(stdin);
		result = num1 % num2;
		printf("\nThe mod is : %d", result);
		printf("\n Do you want to continue(Y or N)?");
		scanf("%c", &choice);
		fflush(stdin);
	} while (choice=='Y'||choice=='y');
	getch();
	return 0;
}
