#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define SIZE 2

typedef struct{
	char FN[40], MI, LN[40];
}nameType;

typedef struct{
	int month, day, yr;
}dateType;

typedef struct{
	unsigned long int id;
	nameType name;
	char address[80];
	dateType enroll;
	int credHrs;
}student;

typedef struct {
	char courseIden [10];
	unsigned long int id;
	int credHours;
	float courseGrade;
}courseRegistration;

void populateStud(student *A);
void populateReg(courseRegistration *B);
void writeStud(student *A);
void writeReg(courseRegistration *B);
void readStud();
void readReg();

int main ()
{
	student X[SIZE];
	courseRegistration Y[SIZE];
	
	populateStud(X);
	populateReg(Y);
	writeStud(X);
	readStud();
	writeReg(Y);
	readReg();
	
	getch();
	return 0;
}

void populateStud(student *A)
{
	int ctr;
	
	for(ctr=0;ctr<SIZE;ctr++){
		printf("\n Enter student information: ");
		printf("\n Enter ID number: ");
		scanf("%lu", &A[ctr].id);
		fflush(stdin);
		printf("\n Enter full name: \n");
		printf("\n First Name: ");
		gets(A[ctr].name.FN);
		fflush(stdin);
		printf("\n Middle Initial: ");
		scanf("%c", &A[ctr].name.MI);
		fflush(stdin);
		printf("\n Last Name: ");
		gets(A[ctr].name.LN);
		fflush(stdin);
		printf("\n Enter Address: ");
		gets(A[ctr].address);
		fflush(stdin);
		printf("\n Enter Credit Hours: ");
		scanf("%d", &A[ctr].credHrs);
		fflush(stdin);
		printf("\n Enter date of enrollment(in numbers): \n ");
		printf("\n Month: ");
		scanf("%d", &A[ctr].enroll.month);
		fflush(stdin);
		printf("\n Day: ");
		scanf("%d", &A[ctr].enroll.day);
		fflush(stdin);
		printf("\n Year: ");
		scanf("%d", &A[ctr].enroll.yr);
		fflush(stdin);
	}
}

void populateReg(courseRegistration *B)
{
	int ctr;
	for(ctr=0;ctr<SIZE;ctr++){
		printf("\n Enter Course information: ");
		printf("\n Enter ID number: ");
		scanf("%lu", &B[ctr].id);
		fflush(stdin);
		printf("\n Enter course Identifier: ");
		scanf("%s", &B[ctr].courseIden);
		fflush(stdin);
		printf("\n Enter Credit Hours: ");
		scanf("%d", &B[ctr].credHours);
		fflush(stdin);
		printf("\n Enter Course Grade: ");
		scanf("%f",&B[ctr].courseGrade);
		fflush(stdin);
	}
}

void writeStud(student *A)
{
	FILE *ptr;
	
	ptr=fopen("StudentRecord.txt", "wb");
	if (ptr==NULL){
		printf("\n Error");
		exit (1);
	}
	fwrite(A, sizeof(student), SIZE, ptr);
	fclose(ptr);
}

void writeReg(courseRegistration *B)
{
	FILE *ptr;
	
	ptr=fopen("CourseRegistration.txt", "wb");
	if (ptr==NULL){
		printf("\n Error");
		exit (1);
	}
	fwrite(B, sizeof(courseRegistration), SIZE, ptr);
	fclose(ptr);
}

void readStud()
{
	student temp[SIZE];
	int ctr;
	FILE *ptr;
	
	ptr=fopen("StudentRecord.txt", "rb");
	if(ptr==NULL){
		printf("\n Error");
		exit(1);
	}
	fread(temp, sizeof(student), SIZE, ptr);
	
	for(ctr=0;ctr<SIZE;ctr++){
		printf("\n \n");
		printf("\n Student Information ");
		printf("\n ID number: %lu", temp[ctr].id);
		printf("\n Full name: ");
		printf("\n First Name: "); 
		puts(temp[ctr].name.FN);
		printf("\n Middle Initial: %c", temp[ctr].name.MI);
		printf("\n Last Name: ");
		puts(temp[ctr].name.LN);
		printf("\n Home Address: ");
		puts(temp[ctr].address);
		printf("\n Credit Hours: %d", temp[ctr].credHrs);
		printf("\n Date of enrollment (MM/DD/YY): %d / %d / %d ", temp[ctr].enroll.month, temp[ctr].enroll.day, temp[ctr].enroll.yr);
	}
}
void readReg()
{
	courseRegistration temp[SIZE];
	int ctr;
	FILE *ptr;
	
	ptr=fopen("CourseRegistration.txt", "rb");
	if(ptr==NULL){
		printf("\n Error");
		exit(1);
	}
	fread(temp, sizeof(courseRegistration), SIZE, ptr);
	
	for(ctr=0;ctr<SIZE;ctr++){
		printf("\n \n");
		printf("\n Course Details");
		printf("\n ID number: %lu", temp[ctr].id);
		printf("\n Course Identifier: %s",temp[ctr].courseIden);
		printf("\n Credit Hours: %d", temp[ctr].credHours);
		printf("\n Grade : %.1f", temp[ctr].courseGrade);
	}	
}
