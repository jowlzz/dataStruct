#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define BSIZE 200
#define SIZE 2

typedef struct{
	char lastName[11];
	char firstName [11];
	char midInit;
	char city[16];
	char zipCode[10];
}Person;

void addRecord (Person X);
void printAll ();

int main ()
{
	int trav;
	Person A;
	
	for(trav=0;trav<SIZE;trav++){
		printf("\n Enter Details of Person: ");
		printf("\n Last Name: ");
		scanf("%s", &A.lastName);
		fflush(stdin);	
		printf("\n First Name: ");
		scanf("%s", &A.firstName);
		fflush(stdin);
		printf("\n Middle Initial: ");
		scanf("%c", &A.midInit);
		fflush(stdin);
		printf("\n City: ");
		scanf("%s", &A.city);
		fflush(stdin);
		printf("\n Zip Code: ");
		scanf("%s", &A.zipCode);
		fflush(stdin);
		addRecord (A);
	}
	printAll();
	getch();
	return 0;
}

void addRecord(Person M)
{
	char buffer[BSIZE];
	FILE *fptr;
	
	fptr=fopen("PersonInformation.txt", "wb");
	sprintf(buffer, "%s|%s|%c|%s|%s|", M.lastName, M.firstName, M.midInit, M.city, M.zipCode);
	fwrite(buffer, sizeof(Person), 1, fptr);
	fclose(fptr);
}

void printAll()
{
	FILE *fptr;
	char *buff;
	char *temp;
	int num;
	char sep[3]="| ";
	
	fptr=fopen("PersonInformation.txt", "rb");
	if (fptr!=NULL){
		fseek(fptr, 0, SEEK_END);
		num=ftell(fptr);
		fseek(fptr, 0, 0);
		printf("\n%-20s", "Last Name");
		printf("%-15s", "First Name");
		printf("%-20s", "Middle Initial");
		printf("%-10s", "City");
		printf("%-5s\n", "Zip Code");
		
		temp=(char *)malloc(num);
		fread(temp, num, 1, fptr);
		buff=strtok(temp, sep);
		num=0;
		while (buff!=NULL){
			if(num==0){
				printf(" %-21s",buff);
			} else if (num==1){
				printf("%-17s", buff);
			} else if (num==2){
				printf("%-16s", buff);
			} else if (num==3){
				printf("%-12s", buff);
			} else if (num==4){
				printf("%-5s", buff);
				printf("\n");
				num=0;
			}	
			num++;
			buff=strtok(NULL, sep);
		}
	}
	fclose(fptr);
}
