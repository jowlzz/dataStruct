#include <stdio.h>
#include <conio.h>
#include <string.h>
#define BSIZE 200

typedef struct{
	char lastName[11];
	char firstName[11];
	char midInit;
	char city[16];
	char zipCode[16];
}Person;

void addRecord(Person, FILE*);
void preview(Person);

int main()
{
	Person P[10] =	{ /* Initializes the array of structures */
					{"Aquino III", "Benigno", 'C', "Manila", "1000"},
					{"Arroyo", "Gloria", 'M', "Pampanga", "2005"},
					{"Estrada", "Joseph", 'E', "Tondo", "1012"},
					{"Ramos", "Fidel", 'V', "Pangasinan", "2401"},
					{"Marcos", "Ferdinand", 'E', "Ilocos Norte", "2914"},
					{"Garcia", "Carlos", 'P', "Bohol", "6325"},
					{"Magsaysay", "Ramon", 'F', "Zambales", "2201"},
					{"Quirino", "Elpidio", 'R', "Ilocos Sur", "2702"},
					{"Osmena", "Sergio", 'S', "Cebu", "6000"},
					{"Laurel", "Jose", 'G', "Batangas", "4232"},
					};
	int i; /* Counter variable */
	FILE* fp = fopen("variableNamesV3.dat", "w+b");
	
	/* Displays the data in the structure for preview. */
	for(i=0; i<10; i++){
		preview(P[i]);		
	}
	
	getch();
	
	/* Writes the structures to the file as a record. */
	if(fp!=NULL){
		for(i=0; i<10; i++){
			addRecord(P[i], fp);
		}
	} else printf("Unsuccessful open.");
	
	fclose(fp);
	
	getch();
	return 0;
}

void addRecord(Person M, FILE* fp)
{
	char buffer[BSIZE];
	
	sprintf(buffer, "%s|%s|%c|%s|%s#", M.lastName, M.firstName, M.midInit, M.city, M.zipCode);
	
	fwrite(buffer, sizeof(Person), 1, fp);
	
	printf("\nFinished writing to file.\n");
}

void preview(Person M)
{
	printf("\nName: %s, %s %c.\n", M.lastName, M.firstName, M.midInit);
	printf("City: %s\n", M.city);
	printf("Zip Code: %s\n", M.zipCode);
}
