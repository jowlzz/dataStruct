
#include <stdio.h>
#include <conio.h>
#include<stdlib.h>
#include <string.h>
#define BSIZE 200

typedef struct{
	char lastName[11];
	char firstName[11];
	char midInit;
	char city[16];
	char zipCode[16];
}Person;


void addRecord (Person X);
void printAll ();

int main ()
{
	int trav;
	Person A;
	
	for(trav=0;trav<10;trav++){
		printf("\n Enter Details of Person: ");
		printf("\n Last Name: ");
		scanf("%s", &A.lastName);
		fflush(stdin);	
		printf("\n First Name: ");
		scanf("%s", &A.firstName);
		fflush(stdin);
		printf("\n Middle Initial: ");
		scanf("%c", &A.midInit);
		fflush(stdin);
		printf("\n City: ");
		scanf("%s", &A.city);
		fflush(stdin);
		printf("\n Zip Code: ");
		scanf("%s", &A.zipCode);
		fflush(stdin);
		addRecord (A);
	}
	printAll();
	getch();
	return 0;
}

void addRecord(Person M)
{
	char buffer[BSIZE];
	FILE *fp;
	
	fp=fopen("PersonInfo.txt" ,"wb");
	if(fp!=NULL){
		sprintf(buffer, "%s|%s|%c|%s|%s#", M.lastName, M.firstName, M.midInit, M.city, M.zipCode);
	
		fwrite(buffer, sizeof(Person), 1, fp);
	
		printf("\nFinished writing to file.\n");
	}
	fclose(fp);
}

void printAll()
{
	int i;
	char buffer[BSIZE];
	char* token;
	char delim[2] = "|";
	FILE *fp;
	
	fp=fopen("PersonInfo.txt", "rb");
	if(fp!=NULL){
		printf("%-20s%-20s%-20s%-20s%-20s\n\n", "Last Name", "First Name", "Mid Init", "City", "Zip Code");
	
		while(fread(buffer, sizeof(Person), 1, fp) != 0){
			token = strtok(buffer, delim);
			for(i=0; i<5; i++){
				printf("%-20s", token);
				token = strtok(NULL, delim);
			}
			printf("\n");
		}

		free(token); /* Save memory, free space :) */
		fclose(fp);
	
}
