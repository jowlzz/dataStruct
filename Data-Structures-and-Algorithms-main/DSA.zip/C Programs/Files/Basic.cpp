#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define SIZE 10

typedef struct{
	char FN[20];
	char LN[20];
	char MI;
}studName;

typedef struct{
	int month;
	int day;
	int year;
}natalDate;

typedef struct{
	studName name;
	unsigned int idNum;
	char course[20];
	int yearLvl;
	natalDate bDay;
}studInfo;

int main()
{
	FILE *ptr;
	studInfo stud[2], view[2];
	int trav;
	
	ptr=fopen("studFile.txt","wb");
	if(ptr!=NULL){
		for(trav=0;trav<2;trav++){
			printf("\n Details of student: ");
			printf("\n Enter Last Name: ");
			scanf("%s", &stud[trav].name.LN);
			fflush(stdin);
			printf("\n Enter First Name: ");
			scanf("%s", &stud[trav].name.FN);
			fflush(stdin);
			printf("\n Enter Middle Initial: ");
			scanf("%s", &stud[trav].name.MI);
			fflush(stdin);
			printf("\n Enter ID number: ");
			scanf("%d", &stud[trav].idNum);
			fflush(stdin);
			printf("\n Enter course: ");
			scanf("%s", &stud[trav].course);
			fflush(stdin);
			printf("\n Enter year level: ");
			scanf("%d", &stud[trav].yearLvl);
			fflush(stdin);
			printf("\n Enter year of birth: ");
			scanf("%d", &stud[trav].bDay.year);
			fflush(stdin);
			printf("\n Enter month of birth(in numbers): ");
			scanf("%d", &stud[trav].bDay.month);
			fflush(stdin);
			printf("\n Enter day of birth: ");
			scanf("%d", &stud[trav].bDay.day);
			fflush(stdin);
		}
		fwrite(stud, sizeof(studInfo), 2, ptr);
	}
	fclose(ptr);
	ptr=fopen("studFile.txt", "rb");
	if(ptr!=NULL){
		fread(view,sizeof(studInfo),3,ptr);
		for(trav=0;trav<2;trav++){
			printf("\n\n Details of student: ");
			printf("\n Enter Last Name: %s", view[trav].name.LN);
			printf("\n Enter First Name: %s", view[trav].name.FN);
			printf("\n Enter Middle Initial: %c", view[trav].name.MI);
			printf("\n Enter ID number: %d", view[trav].idNum);
			printf("\n Enter course: %s", view[trav].course);
			printf("\n Enter year level: %d", view[trav].yearLvl);
			printf("\n Enter year of birth: %d", view[trav].bDay.year);
			printf("\n Enter month of birth(in numbers): %d", view[trav].bDay.month);
			printf("\n Enter day of birth: %d", view[trav].bDay.day);
		}
	}
	fclose(ptr);
	getch();
	return 0;
	
}
