#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 4

typedef unsigned char SET;

typedef struct{
	char FN[20];
	char LN[20];
	char MI;
}studName;

typedef struct {
	studName name;
	int year;
	char gender;
	char course[20];
}student;

void populateArr(student *A);
void write(student info);
void read ();
SET arrToWord (student info);
void displayBinary (SET A);

int main ()
{
	student X[SIZE];
	
	populateArr(X);
	read();
	
	getch();
	return 0;
}

void populateArr(student *A)
{
	student temp;
	int trav;
	
	for(trav=0;trav<SIZE;trav++){
		printf("\n Student Details");
		printf("\n Last Name: ");
		scanf("%s", &temp.name.LN);
		fflush(stdin);
		printf("\n First Name: ");
		scanf("%s", &temp.name.FN);
		fflush(stdin);
		printf("\n Middle Initial: ");
		scanf("%c", &temp.name.MI);
		fflush(stdin);
		printf("\n Year Level: ");
		scanf("%d", &temp.year);
		fflush(stdin);
		printf("\n Course: ");
		scanf("%s", &temp.course);
		fflush(stdin);
		printf("\n Gender: ");
		scanf("%c", &temp.gender);
		fflush(stdin);
		write(temp);
	}
}

void write(student info)
{
	FILE *ptr;
	
	ptr=fopen("Student Details.txt", "ab");
	if(ptr!=NULL){
		fwrite(&info, sizeof(student), 1, ptr);
	}
}

void read ()
{
	student take[SIZE];
	int trav;
	FILE *ptr;
	SET comWord;
	
	ptr=fopen("Student Details.txt", "rb");
	if(ptr!=NULL){
		fread(take, sizeof(student), SIZE, ptr);
		for (trav=0;trav<SIZE;trav++){
			printf("\n Student Details: ");
			printf("\n Last Name: %s", take[trav].name.LN);
			printf("\n First Name: %s", take[trav].name.FN);
			printf("\n Middle Initial: %c .", take[trav].name.MI);
			printf("\n Gender: ");
			(take[trav].gender=='F'||take[trav].gender=='f') ? printf("Female"):printf("Male");
			printf("\n Course: %s", take[trav].course);
			printf("\n Year Level: %d", take[trav].year);
			comWord=arrToWord(take[trav]);
			displayBinary(comWord);
		}	
	}
}

/*1st bit: 1-F, 0-M
  2nd-4th bit (Year): 001-1, 010-2, 011-3, 100-4
  5th-7th bit(Course):001-BSIT, 010-BSCS, 011-ACTMT, 100-BSICT
*/
SET arrToWord (student info)
{
	SET A;
	
	A=((info.gender=='F'||info.gender=='f')?1:0)+ info.year*2;
	
	if (strcmp(info.course, "BSIT")==0){
		A += 0x10;
	} else if (strcmp(info.course, "BSCS")==0){
		A += 0x20;
	} else if (strcmp(info.course, "ACTMT")==0){
		A += 0x30;
	} else {
		A += 0x40;;
	}
	
	return A;
}

void displayBinary (SET A)
{
	unsigned mask;
	int ctr;
	printf("\n Information stored in computer word and binary: ");
	printf("\n Computer Word: %u", A);
	
	mask = 1 << (sizeof(char)*8)-1;
	
	printf("\n In Binary: ");
	for(ctr=7;ctr>-1;ctr--){
		if(mask&A){
			printf("1");
		} else {
			printf("0");
		}
		mask >>=1;
	}
}
