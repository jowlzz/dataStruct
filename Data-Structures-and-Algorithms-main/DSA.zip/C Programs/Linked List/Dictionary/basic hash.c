#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 27

typedef struct node{
	char word[50];
	struct node *next;
}*LL;

typedef LL Dictionary [MAX];

typedef enum{TRUE, FALSE}boolean;

void initialize (Dictionary *A);
void insert (Dictionary *A, char *data);
void deleteElem (Dictionary *A, char *data);
int hash (char *data);
boolean Member (Dictionary A, char *data);
void print (Dictionary A);

int main ()
{
	Dictionary X;
	int action;
	char choice;
	char data[50];
	
	initialize(&X);
	do{
		printf("\n(1) Insert \n(2) Delete \n(3)Display");
		printf("\n Enter action : ");
		scanf("%d", &action);
		fflush(stdin);
		switch(action){
			case 1 : printf("\n Enter word you want to insert: ");
					 scanf("%s", &data);
					 fflush(stdin);
					 insert(&X, data);
					 break;
			case 2 : printf("\n Enter word you want to delete: ");
					 scanf("%s", &data);
					 fflush(stdin);
					 deleteElem(&X, data);
					 break;
			default : print(X);
		}
		printf("\n Do you want to continue (Y or N)? ");
		scanf("%c", &choice);
		fflush(stdin);
	}while (choice=='Y'||choice=='y');
	
	print(X);
	getch();
	return 0;
}

void initialize (Dictionary *A)
{
	int ctr;
	
	for(ctr=0;ctr<MAX;ctr++){
		(*A)[ctr]=NULL;
	}
}

void insert (Dictionary *A, char *data)
{
	int ndx;
	LL temp, *ptr;
	if(Member(*A, data)==FALSE){
		ndx=hash(data);
		ptr=&(*A)[ndx];
		temp=(LL)malloc(sizeof(struct node));
		if(temp!=NULL){
			strcpy(temp->word, data);
			temp->next=*ptr;
			*ptr=temp;
		}
	}
}

void deleteElem (Dictionary *A, char *data)
{
	int ndx;
	LL *ptr, temp;
	
	ndx=hash(data);
	for(ptr=&(*A)[ndx];*ptr!=NULL && strcmp((*ptr)->word,data)!=0;ptr=&(*ptr)->next){}
	if(*ptr!=NULL){
		temp=*ptr;
		*ptr=temp->next;
		free(temp);
	}
}

int hash (char *data)
{
	int p, retVal;
	
	if(data[0]>64&&data[0]<91){
		retVal=65;
	} else {
		retVal=97;
	}
	return (data[0]-retVal);
	
}
boolean Member (Dictionary A, char *data)
{
	int ndx;
	LL trav;
	ndx=hash(data);
	if(A[ndx]!=NULL){
		for(trav=A[ndx];trav!=NULL && strcmp(trav->word, data)!=0;trav=trav->next){}
	}
	return (A[ndx]!=NULL && trav!=NULL? TRUE:FALSE);
}

void print (Dictionary A)
{
	LL trav;
	char ndx;
	int cnt;
	
	for(ndx='A', cnt=0;ndx<='Z';ndx++, cnt++){
		printf("\n Words on letter %c : ",ndx);
		for(trav=A[cnt];trav!=NULL;trav=trav->next){
			printf("\n %s", trav->word);
		}
	}
}
