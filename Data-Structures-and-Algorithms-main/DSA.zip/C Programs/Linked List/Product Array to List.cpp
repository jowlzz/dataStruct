#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct{
	char prodName[20];
	char prodType[20];
	int prodNum;
	int qty;
	float price;
}product;

typedef struct node{
	product prod;
	struct node *next;
}*LIST;

typedef enum{TRUE, FALSE}boolean;
void initList(LIST *L);
void populateList(LIST *L);
boolean prodExist(LIST L, int prodID);
void insertSorted(LIST *L, product data);
void deleteProd(LIST *L, product data);
product deleteFirst(LIST *L);
void displayProduct(product data);
void displayAll(LIST L);

int main ()
{
	LIST A;
	product first = {"Hersheys", "Chocolate", 1315, 190, 38.00};
	product second = {"MAXX", "Candy", 2005, 300, 1.50};
	product temp;
	
	initList(&A);
	
	populateList(&A);
	displayAll(A);
	
	printf("\n The product to be inserted: ");
	displayProduct(first);
	insertSorted(&A, first);
	printf("\n The product to be inserted: ");
	displayProduct(second);
	insertSorted(&A, second);
	
	displayAll(A);
	
	printf("\n The product to be deleted: ");
	displayProduct(first);
	deleteProd(&A, first);
	printf("\n The fist product will be deleted: ");
	temp=deleteFirst(&A);
	displayProduct(temp);
	
	displayAll(A);
	
	return 0;
}
void initList(LIST *L)
{
	*L=NULL;
}

void populateList(LIST *L)
{
	int trav;
	product allItems[] = {{"Cloud9", "Chocolate", 1000, 25, 7.50},
						  {"XO", "Candy", 1020, 100, 1.00},
						  {"Hersheys", "Chocolate", 1315, 30, 35.00},
						  {"Goya", "Chocolate", 1045, 30, 25.00},
						  {"Lipps", "Candy", 2304, 300, 1.50},
						  {"Baby Ruth", "Chocolate", 987, 20, 34.00},
						  {"Kopiko", "Candy", 1154, 400, 1.00},
						  {"Dynamite", "Candy", 1567, 325, 1.50},
						  {"Nerds", "Candy", 1768, 40, 75.00},
						  {"Judge", "Candy", 1256, 200, 2.00},
						  {"Mars", "Chocolate", 1095, 33, 32.50}};
	
	for (trav=0;trav<11;trav++){
		insertSorted(L, allItems[trav]);
	}					  						  
}

boolean prodExist(LIST L, int prodID)
{
	if (L!=NULL){
		for(;L!=NULL&&L->prod.prodNum!=prodID;L=L->next){}	
	}
	return(L!=NULL?TRUE:FALSE);
}
void insertSorted(LIST *L, product data)
{
	LIST temp;
	for(;*L!=NULL && (*L)->prod.prodNum<data.prodNum;L=&(*L)->next){}
	if (prodExist(*L, data.prodNum)==TRUE){
		(*L)->prod.qty=(*L)->prod.qty+data.qty;
		(*L)->prod.price=data.price;	
	} else {
		temp=(LIST)malloc(sizeof(struct node));
		if(temp!=NULL){
			temp->prod=data;
			temp->next=*L;
		    *L=temp;
		} else {
			printf("\n No more memory");
		}
	}
}

void deleteProd(LIST *L, product data)
{
	LIST temp;
	for(;*L!=NULL && (*L)->prod.prodNum!=data.prodNum;L=&(*L)->next){}
	if(*L==NULL){
		printf("\n The product does not exist.");
	} else {
		(*L)->prod.qty=(*L)->prod.qty-data.qty;
		if((*L)->prod.qty<1){
			temp=*L;
			*L=temp->next;
			free(temp);
		}
	}
}

product deleteFirst(LIST *L)
{
	product retVal={"XXX","XXX",0,-1,0.00};
	LIST temp;
	if(*L!=NULL){
		temp=*L;
		retVal=temp->prod;
		*L=temp->next;
		free(temp);
	}
	return retVal;
}

void displayProduct(product data)
{
	printf("\n Product details");
	printf("\n %-10s %-10s %-10s %-10s %-4s", "Name", "Type", "ID Number", "Quantity", "Price(in peso)");
	
	printf("\n %-10s", data.prodName);
	printf("%-14s", data.prodType);
	printf("%-12d", data.prodNum);
	printf("%-10d", data.qty);
	printf("%-4.2f", data.price);
	printf("\n Press anything to continue...");
	getch();
}

void displayAll(LIST L)
{
	printf("\n All Product details");
	printf("\n %-10s %-10s %-10s %-10s %-4s", "Name", "Type", "ID Number", "Quantity", "Price(in peso)");
	for(;L!=NULL;L=L->next){
	printf("\n %-10s", L->prod.prodName);
	printf("%-14s", L->prod.prodType);
	printf("%-12d", L->prod.prodNum);
	printf("%-10d", L->prod.qty);
	printf("%-4.2f", L->prod.price);
	}
	printf("\n Press anything to continue...");
	getch();
}
