/****************************************************************
 *  Name: Stack-Queue Problem 									*
 *	Author: Ventura, Jane Colleen T.							*
 *	Date: 10/09/15 23:35										*
 *	Description: This program reverses the contents in the queue*
 *	using a stack.												*
*****************************************************************/

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct node{
	char elem;
	struct node *next;
}*list;

typedef list Stack;

typedef struct{
	list front;
	list rear;
}Queue;

void initQueue(Queue **);
void initStack(Stack *);
void enqueue(Queue *, char);
void push(Stack *, char);
char dequeue(Queue *);
char pop(Stack *);
void reverse(Queue *);
void display(Queue);

int main()
{
	Queue *B;
	char data, choice;
	
	initQueue(&B);
	
	do {
		printf("\n Enter the data you want to enqueue: ");
		scanf("%c", &data);
		fflush(stdin);
		enqueue(B, data);
		printf("\n Do you want to continue (Y or N)?");
		scanf("%c", &choice);
		fflush(stdin);
	} while(choice=='y' || choice=='Y');
	printf("\n The current data in your queue");
	display(*B);
	reverse(B);
	printf("\n The data in your queue after reversing");
	display(*B);
	getch();
	return 0;
}

void initQueue(Queue **Q)
{
	(*Q)=(Queue *)malloc(sizeof(Queue));
	(*Q)->front=NULL;
	(*Q)->rear=(*Q)->front;
}

void initStack(Stack *S)
{
	(*S)=NULL;
}

void enqueue(Queue *Q, char data)
{
	list temp;

	temp=(list)malloc(sizeof(struct node));
	if(temp!=NULL){
		temp->elem=data;
		temp->next=NULL;
		if(Q->front==NULL){
			Q->front=temp;
		} else {
			Q->rear->next=temp;
		}
		Q->rear=temp;
	}
}
void push(Stack *S, char data)
{
	Stack temp;
	temp=(Stack)malloc(sizeof(struct node));
	if(temp!=NULL){
		temp->elem=data;
		temp->next=*S;
		*S=temp;
	}
}

char dequeue(Queue *Q)
{
	list temp;
	char data;
	
	if(Q->front==NULL){
		printf("\n Queue underflow. There are no contents inside the queue.");
	} else{
		temp=Q->front;
		data=Q->front->elem;
		Q->front=temp->next;
		free(temp);
	}
	return data;
}

char pop(Stack *S)
{
   Stack temp;
   char data;
   if((*S)==NULL){
      printf("\n Stack underflow.");
   } else {
      temp=(*S);
      data=(*S)->elem;
      (*S)=temp->next;
      free(temp);
   }
   return data;
}
void reverse(Queue *Q)
{
	Stack temp;
	char data;
	
	initStack(&temp);
	
	while (Q->front!=NULL){
		data=dequeue(Q);
		push(&temp, data);
	}
	
	while(temp!=NULL){
		data=pop(&temp);
		enqueue(Q, data);
	}
}
void display(Queue Q)
{
	list temp;
	printf("\n The elements are displayed from front to rear");
	for(temp=Q.front;temp!=NULL;temp=temp->next){
		printf("\nData: %c", temp->elem);
	}
}
