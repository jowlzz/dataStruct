#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct cell{
	int elem;
	struct cell *next;
}*list;

typedef struct node{
	list front;
	list rear;
}*Queue;

void initList(Queue *);
void enqueue(Queue , int);
void dequeue(Queue );
void display(Queue );
int main ()
{
    Queue Q;
    int option, newElem;
    char choice;
    
    initList(&Q);
    
    do{
    	printf("\n (1)Enqueue \n (2)Dequeue \n Choose an option(1 or 2): ");
    	scanf("%d", &option);
    	fflush(stdin);
    	switch(option){
    		case 1: printf("\nEnter the element you want to enqueue: ");
    				scanf("%d", &newElem);
    				fflush(stdin);
    				enqueue(Q, newElem);
    				break;
    		case 2: dequeue(Q);
    				break;
    		default: printf("\n Invalid choice");
		}
		printf("\n Do you want to continue (Y or N)?");
		scanf("%c", &choice);
		fflush(stdin);
	} 
	while (choice=='Y'||choice=='y');
	display(Q);
	getch();
	return 0;	
}

void initList(Queue *q)
{
	(*q)=(Queue)malloc(sizeof(struct node));
	(*q)->front=NULL;
	(*q)->rear=(*q)->front;	
}

void enqueue(Queue q, int data)
{
	list temp;
	list l;
	temp=(list) malloc (sizeof(struct cell));
	if (temp!=NULL){
		temp->elem=data;
		temp->next=NULL;
		if (q->rear==NULL){
			q->front=temp;
		} else {
			q->rear->next=temp;
		}
		q->rear=temp;
		}
}

void dequeue(Queue q)
{
	list temp;
	if(q->front!=NULL){
		temp=q->front;
		q->front=temp->next;
		free(temp);
	}
}

void display(Queue q)
{
	list frontTemp;
	
	printf("\n Elements displayed from front to rear: ");
	for(frontTemp=q->front;frontTemp!=NULL;frontTemp=frontTemp->next){
		printf("\n %d", frontTemp->elem);
	}
	printf("\n Elements on the rear: %d", q->rear->elem);
}
