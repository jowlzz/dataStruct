#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct node{
	int elem;
	struct node *next;
} *STACK;

void initStack(STACK *);
void push(STACK *, int newElem);
void pop(STACK *);
void display(STACK );

int main()
{
	STACK list;
	int num, choice;
	char ans;
	
	initStack(&list);
	
	do{
		printf("\n (1) Add \n (2)deleteNode \n Enter action (number only): ");
		scanf("%d", &choice);
		fflush(stdin);
	    switch(choice){
		    case 1: printf("\n Enter the number you want to add to the list: ");
				    scanf("%d", &num);
				    fflush(stdin);
				    push(&list, num);
				    break;
		    case 2: pop(&list);
				    break;
		    default: printf("Option not found");
				     display(list);
				     break;
		}
		printf("\n Do you want to continue? Y or N : ");
		scanf("%c", &ans);
	}
	while (ans=='Y'|| ans=='y');
	display(list);
	getch();
	return 0;
}

void initStack(STACK *L)
{
	*L=NULL;
}

void push(STACK B, int newElem)
{
	if(B->top==SIZE-1){
		printf("\n The stack is full");
	} else {
		B->top++;
		B->elem[B->top]=newElem;
	}
}
void pop(STACK B)
{
	if(B->top!=-1){
			B->top--;		
		}
}
void display(STACK L)
{
	STACK p;
	printf("\n     Element");
	for(p=L;p!=NULL;p=p->next){
		printf("\n       %d", p->elem);
	}
}
