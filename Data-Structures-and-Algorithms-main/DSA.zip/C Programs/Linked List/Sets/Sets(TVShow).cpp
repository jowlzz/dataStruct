#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>


typedef struct node {
	char cName[20];
	struct node *next;
}memSet, *castTV;

typedef enum {TRUE, FALSE} boolean;

void initialize(castTV *W);
boolean Member(castTV *W, char *castMem);
void insert(castTV *W, char *castMem);
void deleteMem(castTV *w, char *castMem);
castTV find(char *castMem);
castTV unionSet(castTV W, castTV G);
castTV intersection(castTV W, castTV G);
castTV difference(castTV , castTV );
void printSet(castTV W);

castTV TWD, GOT;
 
int main ()
{
	castTV A, B, retSet;
	int num, num1;
	char choice, name[30];

	initialize(&TWD);
	initialize(&GOT);
	do{
		printf("\n(1)Insert \n(2)Delete \n(3)Find \n (4)Display \n Choose action: ");
		scanf("%d", &num);
		fflush(stdin);
		switch(num){
			case 1: printf("\n Enter first name of character you want to insert: ");
					scanf("%s", &name);
					fflush(stdin);
					printf("\n (1) The Walking Dead \n (2) Game of Thrones \n Enter the show you want to insert in: ");
					scanf("%d", &num1);
					fflush(stdin);
					num1==1?insert(&TWD, name):insert(&GOT, name);
					break;
			case 2: printf("\n Enter first name of character you want to delete: ");
					scanf("%s", &name);
					fflush(stdin);
					retSet=find(name);
					deleteMem(&retSet, name);
					break;
			case 3: printf("\n Enter first name of character you want to find: ");
					scanf("%s", &name);
					fflush(stdin);
					retSet=find(name);
					printf("\n The element is contained in this set : ");
					printSet(retSet);
					break;
			case 4: printf("\n The elements of the Set containing the names of characters of The Walking Dead");
					printSet(TWD);
					printf("\n The elements of the Set containing the names of characters of the Game of Thrones");
					printSet(GOT);
					break;
			default: printf("\n Invalid Action");
		}
		printf("\n Do you want to continue (Y or N)? ");
		scanf("%c", &choice);
		fflush(stdin);
	}while (choice=='Y'||choice=='y'); 
	
	printf("\n The union of the two sets (all character names in both TV shows combined): ");
	printSet(unionSet(TWD, GOT));
	printf("\n The intersection of the two sets (character names that are common in both TV shows) ");
	printSet(unionSet(TWD, GOT));
	printf("\n The difference of the two sets (character names that are in The Walking Dead but not in the Game of Thrones");
	printSet(difference(TWD, GOT));
	printf("\n The difference of the two sets (character names that are in the Game of Thrones but not in The Walking Dead");
	printSet(difference(GOT, TWD));	
	getch();
	return 0;
}

void initialize(castTV *W)
{
	*W=NULL;
}

boolean Member(castTV W, char *castMem)
{
		for(;W!=NULL && strcmp(W->cName, castMem)!=0;W=W->next){}
	return (W!=NULL?TRUE:FALSE);
}

void insert(castTV *W, char *castMem)
{
	castTV temp;
	
	if (Member(*W, castMem)!=TRUE){
		temp=(castTV)malloc(sizeof(memSet));
		if(temp!=NULL){
			strcpy (temp->cName, castMem);
			temp->next=*W;
			*W=temp;
		}
	} else {
		printf("\n The element already exists.");
	}	
}

void deleteMem(castTV *W, char *castMem)
{
	castTV temp;
	if(*W!=NULL){
		if(Member (*W, castMem)==TRUE){
			for(;*W!=NULL && strcmp((*W)->cName, castMem)!=0;W=&(*W)->next){}
			temp=*W;
			*W=temp->next;
			free(temp);
		} else {
			printf("\n The member you are looking for does not exist in the set");
		}
	}
}

castTV find(char *castMem)
{
	castTV hold;
	if((Member(TWD, castMem)==TRUE) && (Member(GOT, castMem)!=TRUE)){
		hold=TWD;
	} else if (Member(GOT, castMem)==TRUE && (Member(TWD, castMem)!=TRUE)){
		hold=GOT;
	} else {
		hold=NULL;
	}
	return hold;
}
void printSet(castTV showMem)
{
	if(showMem!=NULL){
		for(;showMem!=NULL;showMem=showMem->next){
			printf("\n %s", showMem->cName);
		}
	} else {
		printf("\n The list is empty or does not exist");
	}
}

castTV unionSet(castTV W, castTV G)
{
	castTV charCombine;
	for (;W!=NULL && G!=NULL; W=W->next, G=G->next){
		if(Member(W, G->cName)!=TRUE){
			insert(&charCombine, G->cName);
		} 
		if(Member(G, W->cName)!=TRUE){
			insert(&charCombine, W->cName);
		}
	}
	if(W!=NULL){
		for(;W!=NULL;W=W->next){
			insert(&charCombine, W->cName);
		}
	} else if (G!=NULL){
		for(;W!=NULL;W=W->next){
			insert(&charCombine, W->cName);
		}	
	}
	
}
castTV intersection(castTV W, castTV G)
{
	castTV similarChar;
}
castTV difference(castTV A, castTV B)
{
}
