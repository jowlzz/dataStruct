#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define SIZE 5

typedef struct cell{
	int elem;
	struct cell *next;
}*Set;

void initSet(Set *S);
void populateSet(Set *A, Set *B);
void insertElem(Set *A, int elem);
Set UNION(Set A, Set B);
Set DIFFERENCE(Set A, Set B);
Set INTERSECTION(Set A, Set B);
void printSet (Set C);

int main ()
{
	Set A, B, C;
	
	initSet(&A);
	initSet(&B);
	
	populateSet(&A, &B);
	printf("\n \n First Set");
	printSet(A);
	printf("\n \n Second Set");
	printSet(B);
	C=UNION(A, B);
	printf("\n \n Union Set");
	printSet(C);
	C=DIFFERENCE(A, B);
	printf("\n \n A-B Set");
	printSet(C);
	C=DIFFERENCE(B, A);
	printf("\n \n B-A Set");
	printSet(C);
	C=INTERSECTION(A, B);
	printf("\n \n Intersection Set");
	printSet(C);	
	getch();
	return 0;
}

void initSet(Set *S)
{
	*S=NULL;
}

void populateSet(Set *A, Set *B)
{
	int arrSetA [] ={10, 2, 7, 1, 4};
	int arrSetB []= {6, 8, 5, 2, 10};
	int trav;
	
	for(trav=0;trav<5;trav++){
		insertElem(A, arrSetA[trav]);
	}
	
	for(trav=0;trav<5;trav++){
		insertElem(B, arrSetB[trav]);
	}	
}

void insertElem(Set *A, int elem)
{
	Set temp;
	
	for(;*A!=NULL && (*A)->elem<elem;A=&(*A)->next){}
	
	temp=(Set )malloc(sizeof(struct cell));
	if(temp!=NULL){
		temp->elem=elem;
		temp->next=*A;
		*A=temp;
	}	
}

Set UNION(Set A, Set B)
{
	Set *C, temp, head;
	
	initSet(&head);
		C=&head;
		while (A!=NULL && B!=NULL){
			temp=(Set)malloc(sizeof(struct cell));
			if(temp!=NULL){
				if (A->elem > B->elem){
					temp->elem=B->elem;
					B=B->next;
				} else if (A->elem < B->elem){
					temp->elem=A->elem;
					A=A->next;
				} else {
					temp->elem=B->elem;
					B=B->next;
					A=A->next;
				}
				temp->next=*C;
				*C=temp;
				C=&(*C)->next;
			}
		}
		if (A==NULL && B!=NULL){
			*C=B;
		} else {
			*C=A;
		}
	return head;	
}

Set DIFFERENCE(Set A, Set B)
{
	Set C, *tail, temp;
	
	C=NULL;
	tail=&C;
	
	for	(;A!=NULL;A=A->next){
		for (temp=B;temp!=NULL && temp->elem!=A->elem;temp=temp->next){}
		if(temp==NULL){
			temp=(Set)malloc(sizeof(struct cell));
			if(temp!=NULL){
				temp->elem=A->elem;
				for(tail=&C;*tail!=NULL && (*tail)->elem<A->elem;tail=&(*tail)->next){}
				temp->next=*tail;
				*tail=temp;
			}
		}
	}
	return C;
}

Set INTERSECTION(Set A, Set B)
{
	Set C, *tail, temp;
	
	C=NULL;
	tail=&C;
	
	for	(;A!=NULL;A=A->next){
		for (temp=B;temp!=NULL && temp->elem!=A->elem;temp=temp->next){}
		if(temp!=NULL){
			temp=(Set)malloc(sizeof(struct cell));
			if(temp!=NULL){
				temp->elem=A->elem;
				for(tail=&C;*tail!=NULL && (*tail)->elem<A->elem;tail=&(*tail)->next){}
				temp->next=*tail;
				*tail=temp;
			}
		}
	}
	return C;
}

void printSet(Set C)
{
	for(;C!=NULL;C=C->next){
		printf("\n %d", C->elem);
	}
}
