#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define DELIMITER '['

typedef struct node{
	char elem;
	struct node *sibling;
	struct node *nextLetter;
}*TRIE;
typedef enum{TRUE, FALSE}boolean;

void initialize(TRIE *A);
void insertWord(TRIE *A, char *word);
void deleteWord(TRIE *A, char *word);
boolean search(TRIE A, char *word);
void display (TRIE A);

int main ()
{
	int option;
	char choice;
	char word[50];
	TRIE X;
	
	initialize(&X);
	do{
		printf("\n(1)Insert a word \n(2)Delete a word \n(3)Find out if a word exists \n(4)Display words in the trie \nChoose an action: ");
		scanf("%d", &option);
		fflush(stdin);
		switch(option){
			case 1: printf("\n Enter the word you want to insert: ");
					gets(word);
					fflush(stdin);
					insertWord(&X, word);
					break;
			case 2: printf("\n Enter the word you want to delete: ");
					gets(word);
					fflush(stdin);
					deleteWord(&X, word);
					break;
			case 3: printf("\n Enter the word you are searching for: ");
					gets(word);
					fflush(stdin);
					search(X, word);
					break;
			case 4: display(A);
					break;
			default: printf("\n Invalid action number.");
		} 
		printf("\n Do you want to continue? (Y or N)");
		scanf("%c", &choice);
		fflush(stdin);
	} while (choice=='Y'||choice=='y');
	
	getch();
	return 0;
}

void initialize(TRIE *A)
{
	*A=NULL;
}

void insertWord(TRIE *A, char *word)
{
	TRIE *ptr, temp;
	
	for(ptr=A;*ptr!=NULL && (*ptr)->sibling!=NULL && (*ptr)->elem!=word[0];ptr=&(*ptr)->sibling){}
	if(*ptr==NULL|| (*ptr)->sibling!=NULL){
		
	}
}

void deleteWord(TRIE *A, char *word);
boolean search(TRIE A, char *word);
void display (TRIE A);
