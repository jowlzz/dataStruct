#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct{
	unsigned int idNum;
	char prodDesc [20];
	float prodPrice;
	int prodQty;
}product;

typedef struct node{
	product data;
	struct node *LC;
	struct node *RC;
}*BST;

typedef enum{TRUE, FALSE} boolean;

void initTree(BST *A);
void populateTree (BST *A);
boolean isExist (BST A, unsigned int X);
void insertNode (BST *A, product elem);
void deleteNode (BST *A, unsigned int idNum);
void deleteTree (BST *A);
product deleteMin (BST *A);
void preorderPrint(BST A);
void postorderPrint(BST A);
void inorderPrint(BST A);

int main()
{
	int choice, ID;
	char option;
	BST T;
	product A;
	
	initTree (&T);
	populateTree (&T);
	
	do {
		printf("\n(1)InsertNode \n(2)DeleteNode \n(3)DeleteTree \n(4)InorderPrint");
		printf("\n Enter the number of the function you want to call : ");
		scanf("%d", &choice);
		switch(choice){
			case 1: printf("\n Enter data of the node you want to insert: ");
					printf("\nProduct identifier: ");
					scanf("%d", &A.idNum);
					fflush(stdin);
					printf("\n Product description (Name): ");
					scanf("%s", &A.prodDesc);
					fflush(stdin);
					printf("\n Price: ");
					scanf("%f", &A.prodPrice);
					fflush(stdin);
					printf("\n Quantity: ");
					scanf("%d", &A.prodQty);
					fflush(stdin);
					insertNode(&T, A);
					break;
			case 2: printf("\n Enter ID number of product to be deleted: ");
					scanf("%d", &ID);
					fflush(stdin);
					deleteNode(&T, ID);
					break;
			case 3: printf("\n Are you sure you want to delete the tree (Y or N)? ");
					scanf("%c", &option);
					fflush(stdin);
					if(option=='Y'||option=='y'){
						deleteTree(&T);
					}
					break;
			case 4: inorderPrint(T);
					break;
			default: printf("\n The option you chose is invalid.");
		}
		printf("\n Do you want to continue(Y or N)?");
		scanf("%c", &option);
		fflush(stdin);
	} while (option=='Y'||option=='y');
	
	preorderPrint(T);
	postOrderPrint(T);
	inorderPrint(T);
	return 0;	
}

void initTree(BST *A)
{
	*A=NULL;
}

void populateTree (BST *A)
{
	int trav;
	product data[] = { {1501, "Hersheys", 100.50, 10},
					   {1701, "Toblerone", 150.75, 20},
				   	   {1550, "Cadbury", 200.00, 30},
				   	   {1201, "Kitkat", 97.75, 40},
				   	   {1450, "Ferrero", 150.50, 50},
				   	   {1601, "Meiji", 75.50, 60},
				   	   {1301, "Nestle", 124.50, 70},
				   	   {1525, "Lindt", 175.50, 80},
				   	   {1545, "Valor", 100.50, 90},
				   	   {1455, "Tango", 49.50, 100}
 				 	 };
 				 	 
 	for(trav=0;trav<10;trav++){
 		insertNode(A, data[trav]);
	}
}

void insertNode (BST *A, product elem)
{
	BST temp;
	
	while (*A!=NULL && (*A)->data.idNum != elem.idNum){
		if((*A)->data.idNum < elem.idNum){
			A=&(*A)->RC;
		} else {
			A=&(*A)->LC;
		}
	}
	
	if(isExist(*A, elem)==TRUE){
		if(elem.prodQty > -1){
			(*A)->data.prodQty += elem.prodQty;
			(*A)->data.prodPrice = elem.prodPrice;
		}	
	} else {
		temp=(BST)malloc(sizeof(struct node));
		if(temp!=NULL){
			temp->data=elem;
			temp->LC = temp->RC =NULL;
			*A=temp;
		}
	}		
}

boolean isExist (BST A, unsigned int X)
{
	if (A!=NULL){
		while(A!=NULL && A->data.idNum != X.idNum){
			if(A->data.idNum < X.idNum){
				A=A->RC;
			} else {
				A=A->LC;
			}	
		}
	}
	return (A==NULL? FALSE:TRUE);
}

void deleteNode (BST *A, unsigned int ID)
{
	BST temp, *p;
	
	p=A;
	if (isExist(*A, ID)==FALSE){
		printf("\n The product does not exist in the tree.");;
	} else {
		while(*p!=NULL && (*p)->data.idNum!=ID){
			if((*p)->data.idNum < ID){
				p=&(*p)->RC;
			} else {
				=&(*p)->LC;
			}
		}
		temp=*A;
		if((*p)->LC!=NULL && (*p)->RC!=NULL){
			(*p)->data=deleteMin(A);
		} else {
			(*p)->LC==NULL?(*p)=(*p)->RC:(*p)->LC;
		}
	} 
}

product deleteMin (BST *A)
{
	product ret;
	BST *p, temp;
	p=A;
	
	if (*A!=NULL){
		for(;*p!=NULL; p=&(*p)->LC){}
		temp=*p;
		ret=temp->data;
		free (temp);
	}
	return ret;
}

void deleteTree (BST *A)
{
		
}
void preorderPrint(BST A)
{
	preorderPrint(A->LC);
	preorderPrint(A->RC);
	printf("\n Identifier: %d", A->data.idNum);
	printf("\nDescription: %s", A->data.prodDesc);
	printf("\nPrice: %f", A->data.prodPrice);
	printf("\nQuantity: %d", A->data.prodQty);
}
void postorderPrint(BST A);
{
	printf("\n Identifier: %d", A->data.idNum);
	printf("\nDescription: %s", A->data.prodDesc);
	printf("\nPrice: %f", A->data.prodPrice);
	printf("\nQuantity: %d", A->data.prodQty);
	postorderPrint(A->LC);
	postorderPrint(A->RC);	
}
void inorderPrint(BST A)
{
	inorderPrint(A->LC);
	printf("\n Identifier: %d", A->data.idNum);
	printf("\nDescription: %s", A->data.prodDesc);
	printf("\nPrice: %f", A->data.prodPrice);
	printf("\nQuantity: %d", A->data.prodQty);
	inorderPrint(A->RC);
}
