#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct cell{
	int pNum;
	struct cell *right;
	struct cell *left;
}*BST;

void initialize (BST *T);
void insert (BST *T, int num);
int deleteMin(BST *T);
void display (BST T);

int main ()
{
	char option;
	int data, choice;
	BST A;
	
	initialize(&A);
	do{
		printf("\n(1)Add priority number \n(2)Serve priority number \n(3)Display numbers left \n Choose action : ");
		scanf("%d", &choice);
		fflush(stdin);
		switch(choice){
			case 1: printf("\n Enter priority number of new entry: ");
					scanf("%d", &data);
					fflush(stdin);
					insert(&A, data);
					break;
			case 2: if (A!=NULL){
						printf("\n Person with priority number %d is now being served and deleted from the tree", deleteMin (&A));
					} else {
						printf("\n The tree containing priority numbers is empty");
					}
					break;
			default: display(A);
		}
		printf("\n Do you want to continue (Y or N)? ");
		scanf("%c", &option);
		fflush(stdin);
	} while  (option=='Y'||option=='y');
	
	display(A);
	getch();
	return 0;
}

void initialize (BST *T)
{
	*T=NULL;
}

void insert (BST *T, int num)
{
	BST temp, *trav;
	int data;
	
	temp=(BST)malloc(sizeof(struct cell));
	if(temp!=NULL){
		temp->pNum=num;
		temp->left=temp->right=NULL;
		trav=T;
		while (*trav!=NULL){
			if ()
		}
	}
}
int deleteMin(BST *T);
void display (BST T);
