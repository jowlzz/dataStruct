#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct node{
	int label;
	struct node *right, *left;
}*TREE;

void initTree(TREE *);
int Search (int, TREE);
void deleteNode(TREE *, int node);
int deleteMin(TREE *);
void insertNode(int value, TREE *);
void preorderPrint(TREE);
void postOrderPrint(TREE);
void inorderPrint(TREE);

int main ()
{
	TREE root;
	char option;
	int data, action;
	initTree(&root);
	
	do{
		printf("\n (1) Insert\n(2) Delete Node\n(3) Print\n(4)Search \nEnter number of action: ");
		scanf("%d", &action);
		fflush(stdin);
		switch(action){
			case 1: printf("\n Enter data you want to insert: ");
					scanf("%d", &data);
					fflush(stdin);
					insertNode(data, &root);
					break;
			case 2: printf("\n Enter data of node you want to delete: ");
					scanf("%d", &data);
					fflush(stdin);
					deleteNode(&root, data);
					break;
			case 3:	printf("\n In order display");
					inorderPrint(root);
					break;
			case 4: printf("\n Enter the data you want to search for: ");
					scanf("%d", &data);
					fflush(stdin);
					if(Search(data, root)==1){
						printf("\n The data exists in the tree.");
					} else {
						printf("\n The data does not exist in the tree");
					}
					break;
			default: printf("\n Invalid choice");
		}
		printf("\n Do you want to continue? (Y or N)");
		scanf("%c",&option);
		fflush(stdin);
	} while (option=='Y'||option=='y');
	
	printf("\n Preorder Display");
	preorderPrint(root);
	printf("\n Post Order Display");
	postOrderPrint(root);
	printf("\n In order Display");
	inorderPrint(root);
	getch();
	return 0;
}

void initTree(TREE *R)
{
	*R=NULL;
}
/*Returns zero if element does not exist and returns 1 if it does*/
int Search (int elem, TREE R) 
{
	int retVal;
	retVal=0;
	
	while(R!=NULL&&retVal==0){
		if(elem<R->label){
			R=R->left;
		} else if (elem>R->label){
			R=R->right;
		} else if(elem==R->label){
			retVal=1;
		}
	}
	return retVal;
}

void deleteNode(TREE *R, int node)
{
	TREE temp, *p;
	p=R;
	if (Search(node, *R)==1){
		while((*p)->label!=node){
			if((*p)->label<node){
				p=&(*p)->right;
			} else if((*p)->label>node){
				p=&(*p)->left;
			}
		}
		if((*p)->left!=NULL&&(*p)->right!=NULL){
			(*p)->label=deleteMin(p);
		} else {
			temp=*p;
			(*p)->left!=NULL?(*p)=(*p)->left:*p=(*p)->right;
			free(temp);
		}
	} else {
		printf("\n The value does not exist");
	}
}
int deleteMin(TREE *R)
{
	TREE temp;
	int retVal;
	for(;(*R)!=NULL;R=&(*R)->left){}
		retVal=(*R)->label;
		temp=*R;
		free(temp);
	return retVal;
}

void insertNode(int value, TREE *R)
{
	TREE temp;
	if(Search(value, *R)!=1){
		temp=(TREE)malloc(sizeof(struct node));
		if (temp!=NULL){
			temp->left=temp->right=NULL;
			temp->label=value;
			for(;*R!=NULL;value>(*R)->label?R=&(*R)->right:R=&(*R)->left){}
			*R=temp;
		}
	}
}
void preorderPrint(TREE R)
{
	if(R!=NULL){
		printf("\n%d", R->label);
		preorderPrint(R->left);
		preorderPrint(R->right);
	}
}
void postOrderPrint(TREE R)
{
	if(R!=NULL){
		postOrderPrint(R->left);
		postOrderPrint(R->right);
		printf("\n%d", R->label);
	}
}
void inorderPrint(TREE R)
{
	if(R!=NULL){
		inorderPrint(R->left);
		printf("\n%d", R->label);
		inorderPrint(R->right);
	}
}

