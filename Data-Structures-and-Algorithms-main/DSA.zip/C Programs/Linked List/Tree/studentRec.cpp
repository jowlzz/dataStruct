#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

typedef struct{ 
	char LN[20];
	char FN[20];
	char MI;
}nameType;

typedef struct {
	nameType name;
	char ID[11];
	int year;
	char course [10];
}studType;

typedef struct node{
	studType student;
	struct node *left;
	struct node *right;
}*BST;

typedef enum{TRUE, FALSE}boolean;

void initialize (BST *A);
void populateFILE();
void read(BST *A);
void insert (BST *A, studType data);
studType deleteMin (BST *A);
void deleteNode (BST *A, char *ID);
boolean search (BST A, char *ID);
void preOrder(BST A);
void postOrder(BST A);
void inOrder (BST A);
void printDetails(studType data);

int main ()
{
	BST root;
	char option;
	int action;
	studType data;
	char foundID [11]="14003";
	char notFound [11] = "12098";
	
	initialize(&root);
	populateFILE();
	read(&root);
	
	do{
		printf("\n(1) Insert\n(2) Delete Node\n(3) Print\n(4)Search \nEnter number of action: ");
		scanf("%d", &action);
		fflush(stdin);
		switch(action){
			case 1: printf("\n Enter data you want to insert: ");
					printf("\n Last Name: ");
					gets(data.name.LN);
					fflush(stdin);
					printf("\n First Name: ");
					gets(data.name.FN);
					fflush(stdin);
					printf("\n Middle Initial: ");
					scanf("%c", &data.name.MI);
					fflush(stdin);
					printf("\n ID Number: ");
					gets(data.ID);
					fflush(stdin);
					printf("\n Year Level: ");
					scanf("%d", data.year);
					fflush(stdin);
					printf("\n Course: ");
					gets(data.course);
					fflush(stdin);

					insert(&root, data);
					break;
			case 2: printf("\n Enter ID number of node you want to delete: ");
					gets(data.ID);
					fflush(stdin);
					deleteNode(&root, data.ID);
					break;
			case 3:	printf("\n In order display");
					inOrder(root);
					break;
			case 4: printf("\n Enter the ID number of student you want to search for: ");
					gets(data.ID);
					fflush(stdin);
					if(search(root, data.ID)==TRUE){
						printf("\n The data exists in the tree.");
					} else {
						printf("\n The data does not exist in the tree");
					}
					break;
			default: printf("\n Invalid choice");
		}
		printf("\n Do you want to continue? (Y or N)");
		scanf("%c",&option);
		fflush(stdin);
	} while (option=='Y'||option=='y');
	
	printf("\n Preorder Display");
	preOrder(root);
	printf("\n Post Order Display");
	postOrder(root);
	printf("\n In order Display");
	inOrder(root);
	getch();
	return 0;	
}

void initialize (BST *A)
{
	*A=NULL;
}

void populateFILE()
{
	int x;
	FILE *fptr;
	studType info[]={{{"Ventura", "Jane Colleen", 'T'}, "13001", 3, "BSCS"},
					 {{"Gonzaga", "Klyde", 'D'}, "13009", 3, "BSCE"},
					 {{"Fujii", "Naomi", 'C'}, "14003", 2, "BSCpE"},
					 {{"Bacalyon", "Dave", 'G'}, "12006", 4, "BSCS"},
					 {{"Perez", "Emman", 'A'}, "10012", 1, "BSMATH"},
					 {{"Albano", "Carl", 'A'}, "11018", 3, "BSA"},
					 {{"Olib", "Ethan", 'B'}, "13016", 3, "BSCE"},
					 {{"Oredina", "Dennielle", 'C'}, "13023", 2, "BSIE"},
					 {{"Calis", "Jade", 'B'}, "13027", 1, "BSICT"},
					 {{"Ramirez", "Claire", 'C'}, "10009", 1, "BSCE"}
					};
	fptr=fopen("StudRec.dat", "wb");
	for(x=0;x<10;x++){
		fwrite(&info[x], sizeof(studType), 1, fptr);
	}
	fclose(fptr);
}

void insert (BST *A, studType data)
{
	BST *trav, temp;
	trav=A;
	
	if (search(*A, data.ID)!=TRUE){
		temp=(BST)malloc(sizeof(struct node));
		if (temp!=NULL){
			temp->student=data;
			temp->right=temp->left=NULL;
		}
		while (*trav!=NULL){
			(strcmp((*trav)->student.ID, data.ID)<0?trav=&(*trav)->right:trav=&(*trav)->left);
		}
		*trav=temp;
	}
}

void read(BST *A)
{
	FILE *fptr;
	studType data;
	
	fptr=fopen("StudRec.dat", "rb");
	while (fread(&data, sizeof(studType), 1, fptr)){
		insert (A, data);
	}
	fclose(fptr);

}
studType deleteMin (BST *A)
{
	BST *trav, temp;
	studType data;

	if(*A!=NULL){
		for(trav=A;*trav!=NULL;trav=&(*trav)->left){}
		temp=*trav;
		data=temp->student;
		free(temp);		
	}
	return data;
}

void deleteNode (BST *A, char *ID)
{
	BST *trav, temp;
	
	if (search(*A, ID)==TRUE){
		while((*A)!=NULL && strcmp((*A)->student.ID, ID)!=0){
			if(strcmp((*A)->student.ID, ID)<0){
				A=&(*A)->right;
			} else {
				A=&(*A)->left;
			}
		}
		if((*A)->left!=NULL && (*A)->right!=NULL){
			(*A)->student=deleteMin(A);
		} else {
			temp=*A;
			(*A)->left!=NULL?(*A)=(*A)->left:(*A)=(*A)->right;
			free(temp);
		}
	}		
}

boolean search (BST A, char *ID)
{
	while(A!=NULL && strcmp(A->student.ID, ID)!=0){
		strcmp(A->student.ID, ID)<0?A=A->right:A=A->left;
	}
	return (A!=NULL?TRUE:FALSE);
}

void printDetails(studType data)
{
	char buffer[80];
	
	printf("\n");
	sprintf(buffer, "%s, %s %c.", data.name.LN, data.name.FN, data.name.MI);
	printf("%-30s", buffer);
	printf("%-10s", data.ID);
	printf("%-5d", data.year);
	printf("%-10s", data.course);
}

void preOrder(BST A)
{
	if(A!=NULL){
		printDetails(A->student);
		preOrder(A->left);
		preOrder(A->right);
	}
}

void postOrder(BST A)
{
	if(A!=NULL){
		postOrder(A->left);
		postOrder(A->right);
		printDetails(A->student);
	}
}
void inOrder (BST A)
{
	if(A!=NULL){
		inOrder(A->left);
		printDetails(A->student);
		inOrder(A->right);
	}
}

